package app.enderlab.frostingroyale;

public enum Rarity {
    COMMON("Common", "&7", 150),
    UNCOMMON("Uncommon", "&a", 300),
    RARE("Rare", "&9", 600),
    EPIC("Epic", "&5", 1000),
    LEGENDARY("Legendary", "&6", 1800);

    private final String display;
    private final String color;
    private final int price;

    Rarity(String display, String color, int price) {
        this.display = display;
        this.color = color;
        this.price = price;
    }

    public String display() {
        return display;
    }

    public String color() {
        return color;
    }

    /** Base shop price of a cosmetic of this rarity. */
    public int price() {
        return price;
    }

    public String tag() {
        return color + "&l" + display.toUpperCase();
    }
}
