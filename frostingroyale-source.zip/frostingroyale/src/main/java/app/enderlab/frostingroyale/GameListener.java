package app.enderlab.frostingroyale;

import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerBedEnterEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.projectiles.ProjectileSource;

/** Damage, eliminations, bots and world protection. */
public final class GameListener implements Listener {

    private final FrostingRoyale plugin;

    public GameListener(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    private boolean lobby(World world) {
        return world.equals(plugin.lobby());
    }

    private boolean bypass(Player player) {
        return player.getGameMode() == GameMode.CREATIVE && player.hasPermission("frostingroyale.admin");
    }

    // ------------------------------------------------------------------ damage

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Player victim)) {
            return;
        }
        World world = victim.getWorld();
        if (lobby(world)) {
            event.setCancelled(true);
            if (event.getCause() == EntityDamageEvent.DamageCause.VOID) {
                victim.teleport(plugin.lobbySpawn());
            }
            return;
        }
        if (!world.equals(plugin.arena())) {
            return;
        }
        RoyaleMatch match = plugin.match();
        if (match.isInMatch(victim) && !match.isAlive(victim)) {
            event.setCancelled(true);
            return;
        }
        if (!match.isAlive(victim)) {
            return;
        }

        if (event.getCause() == EntityDamageEvent.DamageCause.VOID) {
            event.setCancelled(true);
            match.onLethal(victim);
            return;
        }

        Player attacker = null;
        String botName = null;
        if (event instanceof EntityDamageByEntityEvent byEntity) {
            Entity damager = byEntity.getDamager();
            if (damager instanceof Projectile projectile) {
                ProjectileSource shooter = projectile.getShooter();
                if (shooter instanceof Player shooterPlayer) {
                    attacker = shooterPlayer;
                } else if (shooter instanceof Entity shooterEntity && match.isBot(shooterEntity.getUniqueId())) {
                    botName = match.botName(shooterEntity.getUniqueId());
                }
            } else if (damager instanceof Player damagerPlayer) {
                attacker = damagerPlayer;
            } else if (match.isBot(damager.getUniqueId())) {
                botName = match.botName(damager.getUniqueId());
            }
        }
        if (attacker != null && attacker.equals(victim)) {
            attacker = null;
        }
        if (!match.canDamage(victim, attacker)) {
            event.setCancelled(true);
            return;
        }
        if (attacker != null) {
            match.recordAttack(victim, attacker);
        } else if (botName != null) {
            match.recordBotAttack(victim, botName);
        }

        boolean hasTotem = victim.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING
                || victim.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
        if (victim.getHealth() - event.getFinalDamage() <= 0.0 && !hasTotem) {
            event.setCancelled(true);
            match.onLethal(victim);
        }
    }

    @EventHandler
    public void onEntityDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        RoyaleMatch match = plugin.match();
        if (match.isBot(entity.getUniqueId())) {
            event.getDrops().clear();
            event.setDroppedExp(0);
            if (entity instanceof Mob mob) {
                event.getDrops().addAll(match.botDrops(mob));
            }
            match.onBotDeath(entity.getUniqueId(), entity.getKiller());
        }
    }

    // ------------------------------------------------------------------ building and items

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!bypass(event.getPlayer()) && isOurs(event.getPlayer().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!bypass(event.getPlayer()) && isOurs(event.getPlayer().getWorld())) {
            event.setCancelled(true);
        }
    }

    private boolean isOurs(World world) {
        return world.equals(plugin.lobby()) || world.equals(plugin.arena());
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (lobby(player.getWorld()) && !bypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (event.getEntity() instanceof Player player && lobby(player.getWorld()) && !bypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        Player player = event.getPlayer();
        if (lobby(player.getWorld()) && !bypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player) || !lobby(player.getWorld())) {
            return;
        }
        if (event.getView().getTopInventory().getHolder() instanceof Menu) {
            return;
        }
        if (!bypass(player)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onHunger(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player player && lobby(player.getWorld())) {
            event.setCancelled(true);
            player.setFoodLevel(20);
        }
    }

    @EventHandler
    public void onBed(PlayerBedEnterEvent event) {
        if (isOurs(event.getPlayer().getWorld())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (event.getSpawnReason() == CreatureSpawnEvent.SpawnReason.CUSTOM) {
            return;
        }
        World world = event.getLocation().getWorld();
        if (world.equals(plugin.lobby())
                || (world.equals(plugin.arena()) && event.getEntity() instanceof Monster)) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void onWeather(WeatherChangeEvent event) {
        if (event.getWorld().equals(plugin.lobby()) && event.toWeatherState()) {
            event.setCancelled(true);
        }
    }
}
