package app.enderlab.frostingroyale;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

/** A one-use kit you start a match with. */
public enum StartPack {
    SCAVENGER("Scavenger Pack", Material.WOODEN_SWORD, 100, "A stone sword, a leather helmet and bread"),
    WARRIOR("Warrior Pack", Material.IRON_SWORD, 220, "An iron sword, a chainmail chestplate and steak"),
    MEDIC("Medic Pack", Material.GOLDEN_APPLE, 180, "Four golden apples and bread");

    private final String display;
    private final Material icon;
    private final int price;
    private final String description;

    StartPack(String display, Material icon, int price, String description) {
        this.display = display;
        this.icon = icon;
        this.price = price;
        this.description = description;
    }

    public String display() {
        return display;
    }

    public Material icon() {
        return icon;
    }

    public int price() {
        return price;
    }

    public String description() {
        return description;
    }

    public String id() {
        return name().toLowerCase();
    }

    public static StartPack byId(String id) {
        for (StartPack pack : values()) {
            if (pack.id().equals(id)) {
                return pack;
            }
        }
        return null;
    }

    public void give(Player player) {
        switch (this) {
            case SCAVENGER -> {
                player.getInventory().addItem(new ItemStack(Material.STONE_SWORD), new ItemStack(Material.BREAD, 6));
                player.getInventory().setHelmet(new ItemStack(Material.LEATHER_HELMET));
            }
            case WARRIOR -> {
                player.getInventory().addItem(new ItemStack(Material.IRON_SWORD), new ItemStack(Material.COOKED_BEEF, 4));
                player.getInventory().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
            }
            case MEDIC -> player.getInventory().addItem(new ItemStack(Material.GOLDEN_APPLE, 4), new ItemStack(Material.BREAD, 4));
        }
    }
}
