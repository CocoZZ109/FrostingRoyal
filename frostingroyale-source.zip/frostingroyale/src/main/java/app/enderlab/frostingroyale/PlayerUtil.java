package app.enderlab.frostingroyale;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.sound.Sound;
import org.bukkit.Color;
import org.bukkit.FireworkEffect;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;

public final class PlayerUtil {

    private PlayerUtil() {
    }

    /** Back to a clean survival player with an empty inventory. */
    public static void reset(Player player) {
        player.getInventory().clear();
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        player.setGameMode(GameMode.SURVIVAL);
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.setFallDistance(0f);
        player.setWalkSpeed(0.2f);
        player.setAllowFlight(false);
        player.setFlying(false);
        player.setInvulnerable(false);
        player.setExp(0f);
        player.setLevel(0);
        player.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
    }

    /** Full health and no effects after a "death" inside a match (inventory is left alone). */
    public static void revive(Player player) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        player.setHealth(20.0);
        player.setFoodLevel(20);
        player.setSaturation(20f);
        player.setFireTicks(0);
        player.setFallDistance(0f);
        player.setVelocity(new org.bukkit.util.Vector(0, 0, 0));
    }

    public static void play(Player player, String key, float volume, float pitch) {
        player.playSound(Sound.sound(Key.key(key), Sound.Source.MASTER, volume, pitch));
    }

    public static void celebrate(Location location) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        world.spawn(location.clone().add(0, 1, 0), Firework.class, firework -> {
            FireworkMeta meta = firework.getFireworkMeta();
            meta.addEffect(FireworkEffect.builder()
                    .withColor(Color.RED, Color.WHITE, Color.GREEN)
                    .with(FireworkEffect.Type.BALL_LARGE)
                    .build());
            firework.setFireworkMeta(meta);
            firework.detonate();
        });
    }
}
