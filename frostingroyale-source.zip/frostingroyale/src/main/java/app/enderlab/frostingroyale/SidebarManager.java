package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Criteria;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** A sidebar with up to 10 lines per player. */
public final class SidebarManager {

    private static final int MAX_LINES = 10;
    private static final String[] ENTRIES = new String[MAX_LINES];

    static {
        for (int i = 0; i < MAX_LINES; i++) {
            ENTRIES[i] = "\u00A7" + i;
        }
    }

    private final Map<UUID, Scoreboard> boards = new HashMap<>();

    public void update(Player player, String title, List<String> lines) {
        Scoreboard board = boards.get(player.getUniqueId());
        if (board == null) {
            board = Bukkit.getScoreboardManager().getNewScoreboard();
            Objective created = board.registerNewObjective("froyale", Criteria.DUMMY, Text.plain(title));
            created.setDisplaySlot(DisplaySlot.SIDEBAR);
            for (int i = 0; i < MAX_LINES; i++) {
                Team team = board.registerNewTeam("l" + i);
                team.addEntry(ENTRIES[i]);
            }
            boards.put(player.getUniqueId(), board);
            player.setScoreboard(board);
        } else if (player.getScoreboard() != board) {
            player.setScoreboard(board);
        }

        Objective objective = board.getObjective("froyale");
        if (objective == null) {
            return;
        }
        objective.displayName(Text.plain(title));
        int count = Math.min(lines.size(), MAX_LINES);
        for (int i = 0; i < MAX_LINES; i++) {
            if (i < count) {
                Team team = board.getTeam("l" + i);
                if (team != null) {
                    team.prefix(Text.plain(lines.get(i)));
                }
                objective.getScore(ENTRIES[i]).setScore(count - i);
            } else {
                board.resetScores(ENTRIES[i]);
            }
        }
    }

    public void remove(Player player) {
        boards.remove(player.getUniqueId());
    }
}
