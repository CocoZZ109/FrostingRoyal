package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;

/** All the player-facing chest menus: play, shop, Battle Pass, locker and stats. */
public final class Menus {

    private static final Material PANE = Material.LIGHT_BLUE_STAINED_GLASS_PANE;
    private static final int[] GRID = {10, 11, 12, 13, 14, 15, 16, 19, 20, 21, 22, 23, 24, 25, 28, 29, 30, 31, 32, 33, 34};

    private final FrostingRoyale plugin;

    public Menus(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    private String coinsLine(Player player) {
        return "&7Your coins: &6" + plugin.data().get(player).coins;
    }

    // ------------------------------------------------------------------ play

    public void play(Player player) {
        RoyaleMatch match = plugin.match();
        PlayerData data = plugin.data().get(player);
        Menu menu = new Menu("&6&lFrosting Royale", 4).fill(PANE);

        boolean queued = match.isQueued(player);
        List<String> playLore = new ArrayList<>();
        playLore.add("&7Drop onto the map, loot chests and");
        playLore.add("&7outlast everyone as the storm closes in.");
        playLore.add("");
        playLore.add("&7Status: " + match.statusText());
        playLore.add("&7In queue: &f" + match.queueSize());
        playLore.add("");
        playLore.add(queued ? "&cClick to leave the queue" : "&aClick to join the queue");
        menu.set(11, Text.icon(queued ? Material.RED_DYE : Material.DIAMOND_SWORD,
                queued ? "&c&lLEAVE QUEUE" : "&a&lPLAY BATTLE ROYALE", playLore), (p, c) -> {
            if (match.isQueued(p)) {
                match.leaveQueue(p);
            } else {
                match.joinQueue(p);
            }
            play(p);
        });
        menu.set(13, Text.icon(Material.EMERALD, "&a&lItem Shop", "&7Daily rotating cosmetics", "", "&eClick to open"), (p, c) -> itemShop(p));
        menu.set(15, Text.icon(Material.NETHER_STAR, "&e&lBattle Pass", "&7Tier " + BattlePass.level(data) + "/" + BattlePass.TIERS
                + (data.premium ? " &6(Premium)" : " &7(Free)"), "", "&eClick to open"), (p, c) -> pass(p, 0));
        menu.set(20, Text.icon(Material.ENDER_CHEST, "&d&lLocker", "&7Equip trails, kill effects,", "&7titles and start packs", "", "&eClick to open"), (p, c) -> locker(p));
        menu.set(22, Text.icon(Material.BOOK, "&b&lStats", "&7Wins, kills and more", "", "&eClick to open"), (p, c) -> stats(p));
        menu.set(24, Text.icon(Material.GOLDEN_HELMET, "&6&lLeaderboard", "&7Top players by wins", "", "&eClick to open"), (p, c) -> leaderboard(p));
        menu.set(4, Text.icon(Material.GOLD_INGOT, "&6&lCoins: " + data.coins, "&7Earn coins by playing matches"));

        List<EventManager.Active> events = plugin.events().active();
        if (!events.isEmpty()) {
            List<String> lines = new ArrayList<>();
            for (EventManager.Active active : events) {
                lines.add("&e" + active.describe());
            }
            menu.set(31, Text.icon(Material.FIREWORK_STAR, "&d&l\u2605 Live Events", lines));
        }
        menu.set(35, Text.icon(Material.BARRIER, "&cClose"), (p, c) -> p.closeInventory());
        menu.open(player);
    }

    // ------------------------------------------------------------------ item shop

    public void itemShop(Player player) {
        ShopManager shop = plugin.shop();
        PlayerData data = plugin.data().get(player);
        Menu menu = new Menu("&a&lItem Shop", 5).fill(PANE);

        long left = shop.secondsUntilRotation();
        List<String> info = new ArrayList<>();
        info.add(coinsLine(player));
        info.add("&7New items in &f" + (left / 3600L) + "h " + ((left % 3600L) / 60L) + "m");
        int discount = plugin.events().discount();
        if (discount > 0) {
            info.add(discount >= 100 ? "&a&lEVERYTHING IS FREE!" : "&a&l" + discount + "% OFF EVERYTHING!");
        }
        menu.set(4, Text.icon(Material.GOLD_INGOT, "&6&lShop info", info));

        List<Cosmetic> items = shop.rotation();
        int[] slots = {11, 15, 19, 20, 21, 23, 24, 25};
        for (int i = 0; i < items.size() && i < slots.length; i++) {
            Cosmetic cosmetic = items.get(i);
            menu.set(slots[i], cosmeticIcon(data, cosmetic, i < 2), (p, c) -> buyCosmetic(p, cosmetic));
        }
        menu.set(38, Text.icon(Material.EXPERIENCE_BOTTLE, "&b&lBoosts & Pass", "&7Coin boosts, XP boosts, the", "&7premium pass and tier skips", "", "&eClick to open"), (p, c) -> boosts(p));
        menu.set(42, Text.icon(Material.CHEST, "&f&lStart Packs", "&7One-use kits to start a match with", "", "&eClick to open"), (p, c) -> packs(p));
        menu.set(40, Text.icon(Material.ARROW, "&7Back"), (p, c) -> play(p));
        menu.open(player);
    }

    private ItemStack cosmeticIcon(PlayerData data, Cosmetic cosmetic, boolean featured) {
        List<String> lore = new ArrayList<>();
        lore.add(cosmetic.rarity().tag() + " &7" + cosmetic.type().display());
        if (cosmetic.type() == CosmeticType.TITLE) {
            lore.add("&7Looks like: " + cosmetic.data());
        }
        lore.add("");
        if (data.owned.contains(cosmetic.id())) {
            lore.add("&a\u2714 OWNED");
        } else {
            int price = plugin.shop().cosmeticPrice(cosmetic);
            int base = cosmetic.rarity().price();
            lore.add(price < base ? "&7Price: &m" + base + "&r &6" + price + " coins" : "&7Price: &6" + price + " coins");
            lore.add("&eClick to buy");
        }
        return Text.icon(cosmetic.icon(), (featured ? "&e\u2605 " : "") + cosmetic.rarity().color() + "&l" + cosmetic.name(), lore);
    }

    private void buyCosmetic(Player player, Cosmetic cosmetic) {
        PlayerData data = plugin.data().get(player);
        if (data.owned.contains(cosmetic.id())) {
            Text.send(player, "&7You already own this.");
            return;
        }
        int price = plugin.shop().cosmeticPrice(cosmetic);
        confirm(player, "Buy " + cosmetic.name() + "?", cosmeticIcon(data, cosmetic, false), () -> {
            if (data.owned.contains(cosmetic.id())) {
                return;
            }
            if (plugin.shop().pay(player, price)) {
                data.owned.add(cosmetic.id());
                Text.send(player, "&aYou bought &f" + cosmetic.rarity().color() + cosmetic.name() + "&a! Equip it in your &b/locker&a.");
            }
            itemShop(player);
        }, () -> itemShop(player));
    }

    /** Yes/No screen shown before every purchase. */
    public void confirm(Player player, String title, ItemStack display, Runnable yes, Runnable no) {
        Menu menu = new Menu("&2" + title, 3).fill(PANE);
        menu.set(13, display);
        menu.set(11, Text.icon(Material.LIME_CONCRETE, "&a&lCONFIRM"), (p, c) -> yes.run());
        menu.set(15, Text.icon(Material.RED_CONCRETE, "&c&lCANCEL"), (p, c) -> no.run());
        menu.open(player);
    }

    // ------------------------------------------------------------------ boosts and packs

    public void boosts(Player player) {
        ShopManager shop = plugin.shop();
        PlayerData data = plugin.data().get(player);
        Menu menu = new Menu("&b&lBoosts & Pass", 3).fill(PANE);

        int coinPrice = shop.price(400);
        ItemStack coinBoost = Text.icon(Material.GOLD_INGOT, "&6&l2x Coins (1 hour)",
                "&7Double coins from matches", "&7for one hour of real time.", data.coinBoostActive() ? "&aActive - buying adds an hour" : "", "&7Price: &6" + coinPrice + " coins");
        menu.set(10, coinBoost, (p, c) -> confirm(p, "Buy 2x Coins?", coinBoost, () -> {
            if (plugin.shop().pay(p, coinPrice)) {
                data.coinBoostUntil = Math.max(System.currentTimeMillis(), data.coinBoostUntil) + 3_600_000L;
                Text.send(p, "&a2x Coins boost active for an extra hour!");
            }
            boosts(p);
        }, () -> boosts(p)));

        int xpPrice = shop.price(400);
        ItemStack xpBoost = Text.icon(Material.EXPERIENCE_BOTTLE, "&d&l2x XP (1 hour)",
                "&7Double Battle Pass XP", "&7for one hour of real time.", data.xpBoostActive() ? "&aActive - buying adds an hour" : "", "&7Price: &6" + xpPrice + " coins");
        menu.set(12, xpBoost, (p, c) -> confirm(p, "Buy 2x XP?", xpBoost, () -> {
            if (plugin.shop().pay(p, xpPrice)) {
                data.xpBoostUntil = Math.max(System.currentTimeMillis(), data.xpBoostUntil) + 3_600_000L;
                Text.send(p, "&a2x XP boost active for an extra hour!");
            }
            boosts(p);
        }, () -> boosts(p)));

        int premiumPrice = shop.price(BattlePass.premiumPrice());
        ItemStack premium = data.premium
                ? Text.icon(Material.NETHER_STAR, "&6&lPremium Battle Pass", "&a\u2714 You own the premium pass!")
                : Text.icon(Material.NETHER_STAR, "&6&lPremium Battle Pass",
                        "&7Unlocks the premium reward on", "&7every one of the 30 tiers.", "", "&7Price: &6" + premiumPrice + " coins");
        menu.set(14, premium, data.premium ? null : (p, c) -> confirm(p, "Buy Premium Pass?", premium, () -> {
            if (plugin.shop().pay(p, premiumPrice)) {
                data.premium = true;
                Text.send(p, "&6&lPREMIUM UNLOCKED! &7Open &b/pass &7to claim your premium rewards.");
            }
            pass(p, 0);
        }, () -> boosts(p)));

        int skipPrice = shop.price(BattlePass.tierSkipPrice());
        ItemStack skip = Text.icon(Material.FEATHER, "&e&lBattle Pass Tier Skip",
                "&7Instantly gain one tier of XP.", "", "&7Price: &6" + skipPrice + " coins");
        menu.set(16, skip, (p, c) -> confirm(p, "Buy a Tier Skip?", skip, () -> {
            if (BattlePass.level(data) >= BattlePass.TIERS) {
                Text.send(p, "&7You already reached the last tier.");
            } else if (plugin.shop().pay(p, skipPrice)) {
                plugin.data().addXp(p, BattlePass.xpPerTier());
            }
            boosts(p);
        }, () -> boosts(p)));

        menu.set(18, Text.icon(Material.ARROW, "&7Back"), (p, c) -> itemShop(p));
        menu.set(22, Text.icon(Material.GOLD_INGOT, coinsLine(player)));
        menu.open(player);
    }

    public void packs(Player player) {
        PlayerData data = plugin.data().get(player);
        Menu menu = new Menu("&f&lStart Packs", 3).fill(PANE);
        int[] slots = {11, 13, 15};
        StartPack[] all = StartPack.values();
        for (int i = 0; i < all.length; i++) {
            StartPack pack = all[i];
            int price = plugin.shop().price(pack.price());
            ItemStack icon = Text.icon(pack.icon(), "&f&l" + pack.display(),
                    "&7" + pack.description(), "&7Used once at the start of a match.", "",
                    "&7You own: &f" + data.packCount(pack.id()),
                    "&7Price: &6" + price + " coins each",
                    "&eClick: buy 1  &8|  &eShift-click: buy 5");
            menu.set(slots[i], icon, (p, c) -> {
                int amount = c.isShiftClick() ? 5 : 1;
                int total = price * amount;
                confirm(p, "Buy " + amount + "x " + pack.display() + "?", icon, () -> {
                    if (plugin.shop().pay(p, total)) {
                        data.packs.merge(pack.id(), amount, Integer::sum);
                        if (data.equippedPack == null) {
                            data.equippedPack = pack.id();
                        }
                        Text.send(p, "&aYou bought &f" + amount + "x " + pack.display() + "&a.");
                    }
                    packs(p);
                }, () -> packs(p));
            });
        }
        menu.set(18, Text.icon(Material.ARROW, "&7Back"), (p, c) -> itemShop(p));
        menu.set(22, Text.icon(Material.GOLD_INGOT, coinsLine(player)));
        menu.open(player);
    }

    // ------------------------------------------------------------------ battle pass

    public void pass(Player player, int page) {
        PlayerData data = plugin.data().get(player);
        int pages = (BattlePass.TIERS + 6) / 7;
        int current = Math.max(0, Math.min(page, pages - 1));
        int level = BattlePass.level(data);

        Menu menu = new Menu("&e&l" + BattlePass.SEASON + " Pass", 6).fill(PANE);
        menu.set(18, Text.icon(Material.LIME_STAINED_GLASS_PANE, "&a&lFREE TRACK"));
        menu.set(27, Text.icon(Material.ORANGE_STAINED_GLASS_PANE, "&6&lPREMIUM TRACK", data.premium ? "&aUnlocked" : "&cLocked"));

        for (int i = 0; i < 7; i++) {
            int tier = current * 7 + i + 1;
            if (tier > BattlePass.TIERS) {
                break;
            }
            boolean reached = level >= tier;
            menu.set(10 + i, Text.icon(reached ? Material.LIME_STAINED_GLASS_PANE : Material.GRAY_STAINED_GLASS_PANE,
                    (reached ? "&a&l" : "&7&l") + "TIER " + tier, reached ? "&aReached!" : "&7Reach this tier with XP"));

            Reward free = BattlePass.free(tier);
            if (free != null) {
                menu.set(19 + i, rewardIcon(free, tier, level, data.claimedFree.contains(tier), true),
                        (p, c) -> claim(p, tier, false, current));
            }
            Reward premium = BattlePass.premium(tier);
            if (premium != null) {
                menu.set(28 + i, rewardIcon(premium, tier, level, data.claimedPremium.contains(tier), data.premium),
                        (p, c) -> claim(p, tier, true, current));
            }
        }

        int xpInto = BattlePass.xpIntoTier(data);
        int per = BattlePass.xpPerTier();
        int filled = Math.min(10, xpInto * 10 / per);
        String bar = "&a" + "\u2588".repeat(filled) + "&8" + "\u2588".repeat(10 - filled);
        menu.set(49, Text.icon(Material.EXPERIENCE_BOTTLE, "&d&lTier " + level + "/" + BattlePass.TIERS,
                bar, "&7" + (level >= BattlePass.TIERS ? "Max tier!" : xpInto + "/" + per + " XP to the next tier"),
                data.xpBoostActive() ? "&a2x XP boost active" : ""));
        if (current > 0) {
            menu.set(45, Text.icon(Material.ARROW, "&ePrevious page"), (p, c) -> pass(p, current - 1));
        }
        if (current < pages - 1) {
            menu.set(53, Text.icon(Material.ARROW, "&eNext page"), (p, c) -> pass(p, current + 1));
        }
        menu.set(47, Text.icon(Material.CHEST_MINECART, "&a&lClaim all", "&7Claims every reward you can", "&7currently collect."), (p, c) -> {
            claimAll(p);
            pass(p, current);
        });
        if (!data.premium) {
            int price = plugin.shop().price(BattlePass.premiumPrice());
            ItemStack buy = Text.icon(Material.NETHER_STAR, "&6&lGet the Premium Pass", "&7Unlock all premium rewards.", "", "&7Price: &6" + price + " coins");
            menu.set(51, buy, (p, c) -> confirm(p, "Buy Premium Pass?", buy, () -> {
                if (plugin.shop().pay(p, price)) {
                    data.premium = true;
                    Text.send(p, "&6&lPREMIUM UNLOCKED!");
                }
                pass(p, current);
            }, () -> pass(p, current)));
        } else {
            menu.set(51, Text.icon(Material.NETHER_STAR, "&6&lPremium unlocked", "&aThank you!"));
        }
        menu.set(48, Text.icon(Material.GOLD_INGOT, coinsLine(player)));
        menu.set(50, Text.icon(Material.ARROW, "&7Back"), (p, c) -> play(p));
        menu.open(player);
    }

    private ItemStack rewardIcon(Reward reward, int tier, int level, boolean claimed, boolean trackUnlocked) {
        List<String> lore = new ArrayList<>();
        lore.add(reward.text());
        lore.add("");
        if (claimed) {
            lore.add("&a\u2714 Claimed");
        } else if (!trackUnlocked) {
            lore.add("&6Premium pass required");
        } else if (level < tier) {
            lore.add("&cReach tier " + tier + " to unlock");
        } else {
            lore.add("&eClick to claim!");
        }
        return Text.icon(reward.icon(), claimed ? "&7Tier " + tier + " reward" : "&f&lTier " + tier + " reward", lore);
    }

    private boolean tryClaim(Player player, int tier, boolean premiumTrack, boolean announce) {
        PlayerData data = plugin.data().get(player);
        Reward reward = premiumTrack ? BattlePass.premium(tier) : BattlePass.free(tier);
        if (reward == null) {
            return false;
        }
        if (BattlePass.level(data) < tier) {
            if (announce) {
                Text.send(player, "&cReach tier " + tier + " first.");
            }
            return false;
        }
        if (premiumTrack && !data.premium) {
            if (announce) {
                Text.send(player, "&6You need the Premium Pass for this reward.");
            }
            return false;
        }
        if ((premiumTrack ? data.claimedPremium : data.claimedFree).contains(tier)) {
            return false;
        }
        (premiumTrack ? data.claimedPremium : data.claimedFree).add(tier);
        plugin.data().grant(player, reward);
        Text.send(player, "&aClaimed: " + reward.text());
        PlayerUtil.play(player, "entity.player.levelup", 0.8f, 1.5f);
        return true;
    }

    private void claim(Player player, int tier, boolean premiumTrack, int page) {
        tryClaim(player, tier, premiumTrack, true);
        pass(player, page);
    }

    private void claimAll(Player player) {
        int count = 0;
        for (int tier = 1; tier <= BattlePass.TIERS; tier++) {
            if (tryClaim(player, tier, false, false)) {
                count++;
            }
            if (tryClaim(player, tier, true, false)) {
                count++;
            }
        }
        if (count == 0) {
            Text.send(player, "&7Nothing to claim right now.");
        }
    }

    // ------------------------------------------------------------------ locker

    public void locker(Player player) {
        Menu menu = new Menu("&d&lLocker", 3).fill(PANE);
        int slot = 10;
        for (CosmeticType type : CosmeticType.values()) {
            menu.set(slot, Text.icon(type.icon(), "&f&l" + type.display() + "s", "&7Choose what you wear", "", "&eClick to open"),
                    (p, c) -> lockerCategory(p, type));
            slot += 2;
        }
        menu.set(16, Text.icon(Material.CHEST, "&f&lStart Pack", "&7Pick the pack you start with", "", "&eClick to open"), (p, c) -> lockerPacks(p));
        menu.set(22, Text.icon(Material.ARROW, "&7Back"), (p, c) -> play(p));
        menu.open(player);
    }

    private void lockerCategory(Player player, CosmeticType type) {
        PlayerData data = plugin.data().get(player);
        Menu menu = new Menu("&d&lLocker - " + type.display() + "s", 5).fill(PANE);
        int index = 0;
        String equipped = type == CosmeticType.TRAIL ? data.trail : type == CosmeticType.KILL_FX ? data.killFx : data.title;
        for (Cosmetic cosmetic : Cosmetics.ofType(type)) {
            if (!data.owned.contains(cosmetic.id()) || index >= GRID.length) {
                continue;
            }
            boolean on = cosmetic.id().equals(equipped);
            List<String> lore = new ArrayList<>();
            lore.add(cosmetic.rarity().tag());
            if (type == CosmeticType.TITLE) {
                lore.add("&7Looks like: " + cosmetic.data());
            }
            lore.add("");
            lore.add(on ? "&a\u2714 EQUIPPED &7- click to unequip" : "&eClick to equip");
            menu.set(GRID[index++], Text.icon(cosmetic.icon(), cosmetic.rarity().color() + "&l" + cosmetic.name(), lore), (p, c) -> {
                equip(p, type, on ? null : cosmetic.id());
                lockerCategory(p, type);
            });
        }
        if (index == 0) {
            menu.set(22, Text.icon(Material.BARRIER, "&cNothing here yet", "&7Buy some in the Item Shop or", "&7earn them in the Battle Pass!"));
        }
        menu.set(36, Text.icon(Material.ARROW, "&7Back"), (p, c) -> locker(p));
        menu.open(player);
    }

    private void equip(Player player, CosmeticType type, String id) {
        PlayerData data = plugin.data().get(player);
        switch (type) {
            case TRAIL -> data.trail = id;
            case KILL_FX -> data.killFx = id;
            case TITLE -> {
                data.title = id;
                plugin.data().refreshName(player);
            }
        }
        Text.send(player, id == null ? "&7Unequipped." : "&aEquipped!");
    }

    private void lockerPacks(Player player) {
        PlayerData data = plugin.data().get(player);
        Menu menu = new Menu("&f&lStart Pack", 3).fill(PANE);
        int[] slots = {11, 13, 15};
        StartPack[] all = StartPack.values();
        for (int i = 0; i < all.length; i++) {
            StartPack pack = all[i];
            boolean on = pack.id().equals(data.equippedPack);
            menu.set(slots[i], Text.icon(pack.icon(), "&f&l" + pack.display(),
                            "&7" + pack.description(), "&7You own: &f" + data.packCount(pack.id()), "",
                            on ? "&a\u2714 SELECTED &7- click to unselect" : "&eClick to select"),
                    (p, c) -> {
                        data.equippedPack = on ? null : pack.id();
                        lockerPacks(p);
                    });
        }
        menu.set(18, Text.icon(Material.ARROW, "&7Back"), (p, c) -> locker(p));
        menu.open(player);
    }

    // ------------------------------------------------------------------ stats

    public void stats(Player player) {
        PlayerData d = plugin.data().get(player);
        double kd = d.deaths == 0 ? d.kills : Math.round(d.kills * 100.0 / d.deaths) / 100.0;
        Menu menu = new Menu("&b&l" + player.getName() + "'s stats", 3).fill(PANE);
        menu.set(11, Text.icon(Material.GOLD_INGOT, "&6Coins", "&7Balance: &6" + d.coins));
        menu.set(13, Text.icon(Material.DIAMOND_SWORD, "&bMatches", "&7Played: &f" + d.games, "&7Wins: &a" + d.wins,
                "&7Deaths: &c" + d.deaths));
        menu.set(15, Text.icon(Material.SKELETON_SKULL, "&cCombat", "&7Eliminations: &a" + d.kills, "&7K/D: &f" + kd));
        menu.set(4, Text.icon(Material.NETHER_STAR, "&eBattle Pass", "&7Tier: &f" + BattlePass.level(d) + "/" + BattlePass.TIERS,
                d.premium ? "&6Premium" : "&7Free pass"));
        menu.set(22, Text.icon(Material.ARROW, "&7Back"), (p, c) -> play(p));
        menu.open(player);
    }

    public void leaderboard(Player player) {
        Menu menu = new Menu("&6&lTop 10 - Wins", 4).fill(PANE);
        int[] slots = {10, 11, 12, 13, 14, 15, 16, 20, 22, 24};
        List<PlayerData> top = plugin.data().topByWins(10);
        for (int i = 0; i < top.size(); i++) {
            PlayerData d = top.get(i);
            ItemStack head = Text.icon(Material.PLAYER_HEAD, "&6#" + (i + 1) + " &f" + d.name, "&7Wins: &a" + d.wins, "&7Eliminations: &a" + d.kills);
            ItemMeta meta = head.getItemMeta();
            if (meta instanceof SkullMeta skull) {
                OfflinePlayer owner = Bukkit.getOfflinePlayer(d.id);
                skull.setOwningPlayer(owner);
                head.setItemMeta(skull);
            }
            menu.set(slots[i], head);
        }
        menu.set(31, Text.icon(Material.ARROW, "&7Back"), (p, c) -> play(p));
        menu.open(player);
    }
}
