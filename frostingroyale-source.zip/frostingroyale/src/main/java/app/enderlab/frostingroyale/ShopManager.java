package app.enderlab.frostingroyale;

import org.bukkit.entity.Player;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Prices (with event discounts), the daily Item Shop rotation, and paying with coins. */
public final class ShopManager {

    private final FrostingRoyale plugin;

    public ShopManager(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    /** A price after any sale or free-shop event. */
    public int price(int base) {
        int discount = plugin.events().discount();
        return (int) Math.max(0, Math.round(base * (100 - discount) / 100.0));
    }

    public int cosmeticPrice(Cosmetic cosmetic) {
        return price(cosmetic.rarity().price());
    }

    /** Today's 8 Item Shop cosmetics. The first two are "featured". Changes every day at midnight UTC. */
    public List<Cosmetic> rotation() {
        long day = LocalDate.now(ZoneOffset.UTC).toEpochDay();
        List<Cosmetic> items = Cosmetics.shopItems();
        Collections.shuffle(items, new Random(day * 7919L + 13L));
        return items.subList(0, Math.min(8, items.size()));
    }

    public long secondsUntilRotation() {
        ZonedDateTime now = ZonedDateTime.now(ZoneOffset.UTC);
        ZonedDateTime next = now.toLocalDate().plusDays(1).atStartOfDay(ZoneOffset.UTC);
        return Math.max(0L, next.toEpochSecond() - now.toEpochSecond());
    }

    /** Takes the coins if the player has enough. */
    public boolean pay(Player player, int cost) {
        PlayerData data = plugin.data().get(player);
        if (data.coins < cost) {
            Text.send(player, "&cYou need &6" + (cost - data.coins) + " &cmore coins.");
            PlayerUtil.play(player, "entity.villager.no", 1f, 1f);
            return false;
        }
        data.coins -= cost;
        PlayerUtil.play(player, "entity.experience_orb.pickup", 1f, 1.2f);
        return true;
    }
}
