package app.enderlab.frostingroyale;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Coins, Battle Pass progress, cosmetics and stats for every player (players.yml). */
public final class DataManager {

    private final FrostingRoyale plugin;
    private final File file;
    private final Map<UUID, PlayerData> players = new HashMap<>();

    public DataManager(FrostingRoyale plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }

    private void load() {
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("players");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                ConfigurationSection s = section.getConfigurationSection(key);
                if (s == null) {
                    continue;
                }
                PlayerData d = new PlayerData(id, s.getString("name", "Unknown"));
                d.coins = s.getLong("coins");
                d.xp = s.getLong("xp");
                d.premium = s.getBoolean("premium");
                d.claimedFree.addAll(s.getIntegerList("claimed-free"));
                d.claimedPremium.addAll(s.getIntegerList("claimed-premium"));
                d.owned.addAll(s.getStringList("owned"));
                d.trail = s.getString("equipped.trail");
                d.killFx = s.getString("equipped.kill-fx");
                d.title = s.getString("equipped.title");
                d.equippedPack = s.getString("pack.equipped");
                ConfigurationSection packs = s.getConfigurationSection("pack.counts");
                if (packs != null) {
                    for (String packId : packs.getKeys(false)) {
                        d.packs.put(packId, packs.getInt(packId));
                    }
                }
                d.coinBoostUntil = s.getLong("boost.coins");
                d.xpBoostUntil = s.getLong("boost.xp");
                d.wins = s.getInt("stats.wins");
                d.kills = s.getInt("stats.kills");
                d.deaths = s.getInt("stats.deaths");
                d.games = s.getInt("stats.games");
                players.put(id, d);
            } catch (IllegalArgumentException ignored) {
                // skip bad entries
            }
        }
    }

    public void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        for (PlayerData d : players.values()) {
            String b = "players." + d.id;
            yaml.set(b + ".name", d.name);
            yaml.set(b + ".coins", d.coins);
            yaml.set(b + ".xp", d.xp);
            yaml.set(b + ".premium", d.premium);
            yaml.set(b + ".claimed-free", new ArrayList<>(d.claimedFree));
            yaml.set(b + ".claimed-premium", new ArrayList<>(d.claimedPremium));
            yaml.set(b + ".owned", new ArrayList<>(d.owned));
            yaml.set(b + ".equipped.trail", d.trail);
            yaml.set(b + ".equipped.kill-fx", d.killFx);
            yaml.set(b + ".equipped.title", d.title);
            yaml.set(b + ".pack.equipped", d.equippedPack);
            for (Map.Entry<String, Integer> entry : d.packs.entrySet()) {
                yaml.set(b + ".pack.counts." + entry.getKey(), entry.getValue());
            }
            yaml.set(b + ".boost.coins", d.coinBoostUntil);
            yaml.set(b + ".boost.xp", d.xpBoostUntil);
            yaml.set(b + ".stats.wins", d.wins);
            yaml.set(b + ".stats.kills", d.kills);
            yaml.set(b + ".stats.deaths", d.deaths);
            yaml.set(b + ".stats.games", d.games);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save players.yml: " + e.getMessage());
        }
    }

    public PlayerData get(Player player) {
        PlayerData d = players.computeIfAbsent(player.getUniqueId(), id -> new PlayerData(id, player.getName()));
        d.name = player.getName();
        return d;
    }

    public PlayerData find(String name) {
        for (PlayerData d : players.values()) {
            if (d.name.equalsIgnoreCase(name)) {
                return d;
            }
        }
        return null;
    }

    public List<PlayerData> topByWins(int limit) {
        List<PlayerData> list = new ArrayList<>(players.values());
        list.sort(Comparator.comparingInt((PlayerData d) -> d.wins).reversed());
        return list.size() > limit ? new ArrayList<>(list.subList(0, limit)) : list;
    }

    /** Adds Battle Pass XP and announces tier-ups. */
    public void addXp(Player player, long amount) {
        PlayerData d = get(player);
        int before = BattlePass.level(d);
        d.xp = Math.max(0L, d.xp + amount);
        int after = BattlePass.level(d);
        if (after > before) {
            Text.send(player, "&e&lTIER UP! &7Battle Pass tier &6" + after + " &7reached. Open &b/pass &7to claim rewards!");
            PlayerUtil.play(player, "entity.player.levelup", 1f, 1f);
        }
    }

    public void addCoins(Player player, long amount) {
        PlayerData d = get(player);
        d.coins = Math.max(0L, d.coins + amount);
    }

    /** Gives a Battle Pass reward to a player. */
    public void grant(Player player, Reward reward) {
        PlayerData d = get(player);
        switch (reward.kind()) {
            case COINS -> d.coins += reward.amount();
            case COSMETIC -> d.owned.add(reward.id());
            case PACK -> d.packs.merge(reward.id(), reward.amount(), Integer::sum);
        }
    }

    /** Re-applies the player's chosen title to their chat name and tab list. */
    public void refreshName(Player player) {
        PlayerData d = get(player);
        Cosmetic title = Cosmetics.get(d.title);
        String prefix = title != null && d.owned.contains(title.id()) ? title.data() + " " : "";
        player.displayName(Text.plain(prefix + "&f" + player.getName()));
        player.playerListName(Text.plain(prefix + "&f" + player.getName()));
    }
}
