package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Events hosted by operators: sales, free shop, double coins/XP, loot frenzy. Saved in events.yml. */
public final class EventManager {

    public enum Type {
        SALE("Shop Sale", Material.EMERALD, "Everything in the shop is cheaper"),
        FREE_SHOP("FREE SHOP", Material.NETHER_STAR, "Everything in the shop costs 0 coins"),
        DOUBLE_COINS("Double Coins", Material.GOLD_INGOT, "Match coin rewards are doubled"),
        DOUBLE_XP("Double XP", Material.EXPERIENCE_BOTTLE, "Battle Pass XP is doubled"),
        LOOT_FRENZY("Loot Frenzy", Material.CHEST, "More chests and way better loot");

        private final String display;
        private final Material icon;
        private final String description;

        Type(String display, Material icon, String description) {
            this.display = display;
            this.icon = icon;
            this.description = description;
        }

        public String display() {
            return display;
        }

        public Material icon() {
            return icon;
        }

        public String description() {
            return description;
        }
    }

    public record Active(Type type, int value, long endMs) {

        public String describe() {
            String name = type == Type.SALE ? value + "% " + type.display() : type.display();
            long seconds = Math.max(0L, (endMs - System.currentTimeMillis()) / 1000L);
            return name + " &7(" + (seconds / 60L) + "m left)";
        }
    }

    private final FrostingRoyale plugin;
    private final File file;
    private final List<Active> active = new ArrayList<>();

    public EventManager(FrostingRoyale plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "events.yml");
        load();
    }

    private void load() {
        if (!file.exists()) {
            return;
        }
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = yaml.getConfigurationSection("events");
        if (section == null) {
            return;
        }
        for (String key : section.getKeys(false)) {
            try {
                Type type = Type.valueOf(section.getString(key + ".type", ""));
                active.add(new Active(type, section.getInt(key + ".value"), section.getLong(key + ".end")));
            } catch (IllegalArgumentException ignored) {
                // skip bad entries
            }
        }
        prune();
    }

    private void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        int i = 0;
        for (Active a : active) {
            yaml.set("events." + i + ".type", a.type().name());
            yaml.set("events." + i + ".value", a.value());
            yaml.set("events." + i + ".end", a.endMs());
            i++;
        }
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save events.yml: " + e.getMessage());
        }
    }

    /** Removes finished events (and tells everyone). */
    public void prune() {
        long now = System.currentTimeMillis();
        boolean changed = false;
        Iterator<Active> it = active.iterator();
        while (it.hasNext()) {
            Active a = it.next();
            if (a.endMs() <= now) {
                it.remove();
                changed = true;
                for (Player player : Bukkit.getOnlinePlayers()) {
                    Text.send(player, "&7The &e" + a.type().display() + " &7event has ended.");
                }
            }
        }
        if (changed) {
            save();
        }
    }

    public List<Active> active() {
        prune();
        return new ArrayList<>(active);
    }

    public void start(Type type, int value, int minutes) {
        long end = System.currentTimeMillis() + minutes * 60_000L;
        active.removeIf(a -> a.type() == type);
        active.add(new Active(type, value, end));
        save();

        Active started = new Active(type, value, end);
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(Text.plain("&8&m                                        "));
            player.sendMessage(Text.plain("&6&l\u2605 EVENT STARTED: &e&l" + (type == Type.SALE ? value + "% " : "") + type.display()));
            player.sendMessage(Text.plain("&7" + type.description() + " &8- &7for &f" + minutes + " minutes"));
            player.sendMessage(Text.plain("&8&m                                        "));
            PlayerUtil.play(player, "entity.player.levelup", 1f, 0.8f);
        }
        plugin.getLogger().info("Event started: " + started.type() + " " + minutes + "min");
    }

    public void endAll() {
        if (active.isEmpty()) {
            return;
        }
        active.clear();
        save();
        for (Player player : Bukkit.getOnlinePlayers()) {
            Text.send(player, "&7All events were ended by an operator.");
        }
    }

    // ------------------------------------------------------------------ effects

    /** Percent off everything in the shop (0-100). */
    public int discount() {
        int best = 0;
        for (Active a : active()) {
            if (a.type() == Type.FREE_SHOP) {
                return 100;
            }
            if (a.type() == Type.SALE) {
                best = Math.max(best, a.value());
            }
        }
        return Math.min(100, best);
    }

    public boolean isActive(Type type) {
        for (Active a : active()) {
            if (a.type() == type) {
                return true;
            }
        }
        return false;
    }

    public boolean lootFrenzy() {
        return isActive(Type.LOOT_FRENZY);
    }

    /** 1x normally, +1 for the event, +1 for the player's own boost. */
    public int coinMultiplier(PlayerData data) {
        return 1 + (isActive(Type.DOUBLE_COINS) ? 1 : 0) + (data.coinBoostActive() ? 1 : 0);
    }

    public int xpMultiplier(PlayerData data) {
        return 1 + (isActive(Type.DOUBLE_XP) ? 1 : 0) + (data.xpBoostActive() ? 1 : 0);
    }
}
