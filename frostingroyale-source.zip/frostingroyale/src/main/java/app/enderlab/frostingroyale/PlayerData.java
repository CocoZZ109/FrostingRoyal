package app.enderlab.frostingroyale;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class PlayerData {

    public final UUID id;
    public String name;

    public long coins;
    public long xp;
    public boolean premium;
    public final Set<Integer> claimedFree = new HashSet<>();
    public final Set<Integer> claimedPremium = new HashSet<>();

    public final Set<String> owned = new HashSet<>();
    public String trail;
    public String killFx;
    public String title;

    public String equippedPack;
    public final Map<String, Integer> packs = new HashMap<>();

    public long coinBoostUntil;
    public long xpBoostUntil;

    public int wins;
    public int kills;
    public int deaths;
    public int games;

    public PlayerData(UUID id, String name) {
        this.id = id;
        this.name = name;
    }

    public boolean coinBoostActive() {
        return coinBoostUntil > System.currentTimeMillis();
    }

    public boolean xpBoostActive() {
        return xpBoostUntil > System.currentTimeMillis();
    }

    public int packCount(String packId) {
        return packs.getOrDefault(packId, 0);
    }
}
