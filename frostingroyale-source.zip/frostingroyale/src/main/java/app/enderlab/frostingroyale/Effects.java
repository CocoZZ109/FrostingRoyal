package app.enderlab.frostingroyale;

import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;

/** Trails and kill effects. Particle names are looked up safely so a renamed particle never breaks the plugin. */
public final class Effects {

    private static final Map<String, Particle> CACHE = new HashMap<>();

    private Effects() {
    }

    /** First particle that exists from a comma-separated list of names (or null). */
    public static Particle particle(String candidates) {
        if (CACHE.containsKey(candidates)) {
            return CACHE.get(candidates);
        }
        Particle found = null;
        for (String name : candidates.split(",")) {
            try {
                found = Particle.valueOf(name.trim());
                break;
            } catch (IllegalArgumentException ignored) {
                // try the next name
            }
        }
        CACHE.put(candidates, found);
        return found;
    }

    public static void trail(Player player, Cosmetic cosmetic) {
        Particle particle = particle(cosmetic.data());
        if (particle == null) {
            return;
        }
        Location location = player.getLocation().add(0, 0.2, 0);
        player.getWorld().spawnParticle(particle, location, 3, 0.3, 0.1, 0.3, 0.01);
    }

    public static void killEffect(String key, Location location) {
        World world = location.getWorld();
        if (world == null) {
            return;
        }
        switch (key) {
            case "lightning" -> world.strikeLightningEffect(location);
            case "firework" -> PlayerUtil.celebrate(location);
            case "hearts" -> burst(world, location, "HEART");
            case "flames" -> burst(world, location, "FLAME");
            case "snow" -> burst(world, location, "SNOWFLAKE");
            default -> burst(world, location, "SMOKE,SMOKE_NORMAL");
        }
    }

    private static void burst(World world, Location location, String particleNames) {
        Particle particle = particle(particleNames);
        if (particle != null) {
            world.spawnParticle(particle, location.clone().add(0, 1, 0), 25, 0.6, 0.8, 0.6, 0.05);
        }
    }
}
