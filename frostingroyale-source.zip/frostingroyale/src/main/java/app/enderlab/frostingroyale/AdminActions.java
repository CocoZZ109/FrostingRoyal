package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.io.IOException;

/** Maintenance mode, scheduled shutdowns, the map centre and the "lobby built" flag (state.yml). */
public final class AdminActions {

    private final FrostingRoyale plugin;
    private final File file;
    private boolean maintenance;
    private boolean lobbyBuilt;
    private double centerX;
    private double centerZ;
    private BukkitTask shutdownTask;

    public AdminActions(FrostingRoyale plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "state.yml");
        if (file.exists()) {
            YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
            maintenance = yaml.getBoolean("maintenance", false);
            lobbyBuilt = yaml.getBoolean("lobby-built", false);
            centerX = yaml.getDouble("center-x", 0.0);
            centerZ = yaml.getDouble("center-z", 0.0);
        }
    }

    private void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("maintenance", maintenance);
        yaml.set("lobby-built", lobbyBuilt);
        yaml.set("center-x", centerX);
        yaml.set("center-z", centerZ);
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save state.yml: " + e.getMessage());
        }
    }

    public boolean lobbyBuilt() {
        return lobbyBuilt;
    }

    public void setLobbyBuilt(boolean built) {
        this.lobbyBuilt = built;
        save();
    }

    public double centerX() {
        return centerX;
    }

    public double centerZ() {
        return centerZ;
    }

    public void setCenter(double x, double z) {
        this.centerX = x;
        this.centerZ = z;
        save();
    }

    public boolean maintenance() {
        return maintenance;
    }

    /** While on, only operators can join. Switching it on kicks everyone else. */
    public void setMaintenance(boolean on) {
        this.maintenance = on;
        save();
        if (on) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (!canBypass(player)) {
                    player.kick(Text.plain("&6&lFrostingRoyale\n&7The server is in maintenance mode.\n&7Please come back soon!"));
                }
            }
        }
    }

    public static boolean canBypass(Player player) {
        return player.isOp() || player.hasPermission("frostingroyale.admin");
    }

    public boolean shutdownScheduled() {
        return shutdownTask != null;
    }

    public void scheduleShutdown(int seconds, String reason) {
        cancelShutdown();
        final int total = Math.max(5, seconds);
        shutdownTask = new BukkitRunnable() {
            int left = total;

            @Override
            public void run() {
                if (left <= 0) {
                    cancel();
                    shutdownTask = null;
                    stopNow(reason);
                    return;
                }
                if (left == total || left == 300 || left == 180 || left == 120 || left == 60 || left == 30
                        || left == 10 || left <= 5) {
                    announce("&cThe server will shut down in &f"
                            + (left >= 60 ? (left / 60) + " min " + (left % 60) + "s" : left + "s") + " &c- " + reason);
                }
                left--;
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }

    public void cancelShutdown() {
        if (shutdownTask != null) {
            shutdownTask.cancel();
            shutdownTask = null;
            announce("&aThe scheduled shutdown was cancelled.");
        }
    }

    /** Saves everything, kicks all players and stops the server. */
    public void stopNow(String reason) {
        plugin.match().shutdown();
        plugin.saveAll();
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.kick(Text.plain("&6&lFrostingRoyale\n&7The server is shutting down: &f" + reason + "\n&7Please come back soon!"));
        }
        Bukkit.shutdown();
    }

    private void announce(String message) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            Text.send(player, message);
        }
        plugin.getLogger().info(message.replaceAll("&.", ""));
    }
}
