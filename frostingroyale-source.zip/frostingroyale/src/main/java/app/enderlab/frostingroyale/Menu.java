package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

/** A chest menu. Every slot can have an item and a click action. */
public final class Menu implements InventoryHolder {

    public interface Click {
        void on(Player player, ClickType type);
    }

    private final Inventory inventory;
    private final Map<Integer, Click> handlers = new HashMap<>();

    public Menu(String title, int rows) {
        this.inventory = Bukkit.createInventory(this, rows * 9, Text.plain(title));
    }

    public Menu fill(Material material) {
        ItemStack filler = Text.icon(material, " ");
        for (int slot = 0; slot < inventory.getSize(); slot++) {
            inventory.setItem(slot, filler);
        }
        return this;
    }

    public Menu set(int slot, ItemStack item, Click click) {
        inventory.setItem(slot, item);
        if (click != null) {
            handlers.put(slot, click);
        } else {
            handlers.remove(slot);
        }
        return this;
    }

    public Menu set(int slot, ItemStack item) {
        return set(slot, item, null);
    }

    public int size() {
        return inventory.getSize();
    }

    public void open(Player player) {
        player.openInventory(inventory);
    }

    void handle(Player player, int slot, ClickType type) {
        Click click = handlers.get(slot);
        if (click != null) {
            click.on(player, type);
        }
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
