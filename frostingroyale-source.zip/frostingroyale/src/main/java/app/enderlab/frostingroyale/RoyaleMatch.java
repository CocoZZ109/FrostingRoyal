package app.enderlab.frostingroyale;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.WorldBorder;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.entity.Skeleton;
import org.bukkit.entity.Zombie;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

/**
 * The battle royale. Players queue in the lobby, glide down onto the map, loot chests, and the storm
 * (world border) closes in. Bots (zombies and skeletons) fill empty spots when few players are queued.
 */
public final class RoyaleMatch {

    public enum State { WAITING, COUNTDOWN, RUNNING, ENDING }

    private static final int[] WAIT = {90, 60, 45, 30, 20};
    private static final int[] SHRINK = {60, 45, 30, 30, 20};
    private static final double[] FRACTION = {0.60, 0.35, 0.18, 0.08, 0.02};
    private static final String[] BOT_NAMES = {"Frosty", "Blaze", "Shadow", "Viper", "Ghost", "Rogue", "Nova", "Titan",
            "Pixel", "Storm", "Ninja", "Echo", "Jinx", "Ace", "Zed", "Cobra", "Flash", "Rex", "Luna", "Bolt"};

    private final FrostingRoyale plugin;
    private final Random random = new Random();

    private State state = State.WAITING;
    private final Set<UUID> queue = new LinkedHashSet<>();
    private final Set<UUID> alive = new LinkedHashSet<>();
    private final Set<UUID> participants = new LinkedHashSet<>();
    private final Set<UUID> gliding = new LinkedHashSet<>();
    private final Set<UUID> bots = new LinkedHashSet<>();
    private final Map<UUID, String> botNames = new HashMap<>();
    private final Map<UUID, Integer> botMissing = new HashMap<>();
    private final Map<UUID, Integer> killsPlayers = new HashMap<>();
    private final Map<UUID, Integer> killsBots = new HashMap<>();
    private final Map<UUID, Long> protectedUntil = new HashMap<>();
    private final Map<UUID, StartPack> pendingPack = new HashMap<>();
    private final Map<UUID, UUID> lastAttacker = new HashMap<>();
    private final Map<UUID, Long> lastAttackTime = new HashMap<>();
    private final Map<UUID, String> lastBotAttacker = new HashMap<>();
    private final List<Location> chests = new ArrayList<>();

    private BukkitRunnable waitTask;
    private BukkitRunnable countdownTask;
    private BukkitRunnable mainTask;
    private BukkitRunnable landingTask;
    private BukkitRunnable setupTask;

    private int waitSeconds;
    private int countdownLeft;
    private boolean botMatch;
    private double initialSize;
    private double currentSize;
    private double startSize;
    private double targetSize;
    private int phase;
    private int phaseTimer;
    private boolean shrinking;
    private int supplyTimer;
    private int elapsed;

    public RoyaleMatch(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    // ------------------------------------------------------------------ config

    private int minPlayers() {
        return Math.max(1, plugin.getConfig().getInt("queue.min-players", 2));
    }

    private int maxPlayers() {
        return Math.max(2, plugin.getConfig().getInt("queue.max-players", 20));
    }

    private boolean botsEnabled() {
        return plugin.getConfig().getBoolean("bots.enabled", true);
    }

    private World arena() {
        return plugin.arena();
    }

    public State state() {
        return state;
    }

    // ------------------------------------------------------------------ queue

    public boolean isQueued(Player player) {
        return queue.contains(player.getUniqueId());
    }

    public int queueSize() {
        return queue.size();
    }

    public void joinQueue(Player player) {
        if (state == State.RUNNING || state == State.ENDING) {
            Text.send(player, "&cA match is in progress. Join the queue when it ends!");
            return;
        }
        if (queue.contains(player.getUniqueId())) {
            Text.send(player, "&7You are already in the queue.");
            return;
        }
        if (queue.size() >= maxPlayers()) {
            Text.send(player, "&cThe queue is full.");
            return;
        }
        queue.add(player.getUniqueId());
        Text.send(player, "&aYou joined the queue &8(" + queue.size() + "/" + maxPlayers() + ")");
        if (botsEnabled() && queue.size() < minPlayers()) {
            Text.send(player, "&7Not enough players? Bots will join in &6"
                    + plugin.getConfig().getInt("bots.wait-seconds", 25) + "s&7.");
        }
        if (state == State.WAITING) {
            startWaiting();
        }
    }

    public void leaveQueue(Player player) {
        if (queue.remove(player.getUniqueId())) {
            Text.send(player, "&7You left the queue.");
        }
        if (queue.isEmpty()) {
            cancelQueueTasks();
        }
    }

    private void cancelQueueTasks() {
        if (waitTask != null) {
            waitTask.cancel();
            waitTask = null;
        }
        if (countdownTask != null) {
            countdownTask.cancel();
            countdownTask = null;
        }
        if (state == State.COUNTDOWN) {
            state = State.WAITING;
        }
        waitSeconds = 0;
    }

    private void startWaiting() {
        if (waitTask != null) {
            return;
        }
        waitSeconds = 0;
        waitTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (state != State.WAITING || queue.isEmpty()) {
                    waitTask = null;
                    cancel();
                    return;
                }
                waitSeconds++;
                int real = queue.size();
                boolean enough = real >= minPlayers();
                boolean botsReady = botsEnabled() && waitSeconds >= plugin.getConfig().getInt("bots.wait-seconds", 25);
                if (enough || botsReady || real >= maxPlayers()) {
                    waitTask = null;
                    cancel();
                    beginCountdown();
                }
            }
        };
        waitTask.runTaskTimer(plugin, 20L, 20L);
    }

    private void beginCountdown() {
        state = State.COUNTDOWN;
        countdownLeft = Math.max(5, plugin.getConfig().getInt("queue.countdown", 20));
        plugin.pregen(null);
        countdownTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (state != State.COUNTDOWN || queue.isEmpty()) {
                    countdownTask = null;
                    state = State.WAITING;
                    cancel();
                    return;
                }
                if (countdownLeft <= 0) {
                    countdownTask = null;
                    cancel();
                    start();
                    return;
                }
                if (countdownLeft <= 5 || countdownLeft % 10 == 0) {
                    for (UUID id : queue) {
                        Player p = Bukkit.getPlayer(id);
                        if (p != null) {
                            Text.send(p, "&eThe match starts in &6" + countdownLeft + "s");
                        }
                    }
                }
                countdownLeft--;
            }
        };
        countdownTask.runTaskTimer(plugin, 0L, 20L);
    }

    // ------------------------------------------------------------------ admin controls

    public boolean forceStart() {
        if (queue.isEmpty() || (state != State.WAITING && state != State.COUNTDOWN)) {
            return false;
        }
        cancelQueueTasks();
        start();
        return true;
    }

    public void forceEnd() {
        if (state == State.RUNNING) {
            end(null);
        }
    }

    public void skipPhase() {
        if (state == State.RUNNING) {
            phaseTimer = 1;
        }
    }

    public void supplyDropNow() {
        if (state == State.RUNNING) {
            supplyDrop();
        }
    }

    // ------------------------------------------------------------------ starting

    private void start() {
        List<Player> players = new ArrayList<>();
        for (UUID id : queue) {
            Player p = Bukkit.getPlayer(id);
            if (p != null && p.isOnline()) {
                players.add(p);
            }
        }
        queue.clear();
        if (players.isEmpty()) {
            state = State.WAITING;
            return;
        }
        state = State.RUNNING;

        World world = arena();
        Location center = plugin.mapCenter();
        initialSize = Math.max(100, plugin.getConfig().getInt("arena.initial-size", 300));
        currentSize = initialSize;
        startSize = initialSize;
        WorldBorder border = world.getWorldBorder();
        border.setCenter(center.getX(), center.getZ());
        border.setSize(initialSize);
        border.setDamageAmount(2.0);
        border.setDamageBuffer(0.0);
        border.setWarningDistance(10);

        botMatch = players.size() < minPlayers();
        phase = 0;
        phaseTimer = WAIT[0];
        shrinking = false;
        supplyTimer = Math.max(30, plugin.getConfig().getInt("arena.supply-interval", 120));
        elapsed = 0;
        lastAttacker.clear();
        lastBotAttacker.clear();

        for (Player player : players) {
            begin(player, center);
        }
        broadcast("&6&lThe match has begun! &7Glide down and find loot!");

        // chests and bots are created a few per tick so the server does not freeze
        List<Runnable> setup = new ArrayList<>();
        double chestScale = plugin.events().lootFrenzy() ? 1.5 : 1.0;
        int chestCount = (int) Math.round(plugin.getConfig().getInt("arena.chests", 70) * chestScale);
        for (int i = 0; i < chestCount; i++) {
            setup.add(() -> placeChest(LootTable.ChestType.NORMAL));
        }
        if (botsEnabled()) {
            int fillTo = Math.max(2, plugin.getConfig().getInt("bots.fill-to", 12));
            int botCount = Math.max(0, fillTo - players.size());
            for (int i = 0; i < botCount; i++) {
                setup.add(this::spawnBot);
            }
        }
        setupTask = new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                int done = 0;
                while (index < setup.size() && done < 3) {
                    setup.get(index++).run();
                    done++;
                }
                if (index >= setup.size() || state != State.RUNNING) {
                    setupTask = null;
                    cancel();
                }
            }
        };
        setupTask.runTaskTimer(plugin, 1L, 1L);

        mainTask = new BukkitRunnable() {
            @Override
            public void run() {
                tickSecond();
            }
        };
        mainTask.runTaskTimer(plugin, 20L, 20L);

        landingTask = new BukkitRunnable() {
            @Override
            public void run() {
                landingTick();
            }
        };
        landingTask.runTaskTimer(plugin, 10L, 5L);
    }

    private void begin(Player player, Location center) {
        UUID id = player.getUniqueId();
        alive.add(id);
        participants.add(id);
        killsPlayers.put(id, 0);
        killsBots.put(id, 0);

        PlayerUtil.reset(player);
        double angle = random.nextDouble() * Math.PI * 2;
        double radius = Math.sqrt(random.nextDouble()) * initialSize * 0.35;
        double height = plugin.getConfig().getInt("arena.drop-height", 220);
        Location drop = new Location(arena(), center.getX() + Math.cos(angle) * radius, height,
                center.getZ() + Math.sin(angle) * radius, (float) Math.toDegrees(angle), 20f);
        player.teleport(drop);
        player.getInventory().setChestplate(new ItemStack(Material.ELYTRA));
        player.setGliding(true);
        gliding.add(id);

        PlayerData data = plugin.data().get(player);
        StartPack pack = StartPack.byId(data.equippedPack);
        if (pack != null && data.packCount(pack.id()) > 0) {
            data.packs.merge(pack.id(), -1, Integer::sum);
            pendingPack.put(id, pack);
        }
        player.showTitle(Title.title(Text.plain("&6&lGLIDE DOWN!"), Text.plain("&7Aim for a spot and find loot"),
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(3), Duration.ofMillis(500))));
    }

    private void landingTick() {
        for (UUID id : new ArrayList<>(gliding)) {
            Player player = Bukkit.getPlayer(id);
            if (player == null || !alive.contains(id)) {
                gliding.remove(id);
                continue;
            }
            boolean grounded = player.isOnGround() || player.getLocation().getBlock().isLiquid();
            if ((!player.isGliding() && grounded) || elapsed > 90) {
                land(player);
            }
        }
    }

    private void land(Player player) {
        UUID id = player.getUniqueId();
        gliding.remove(id);
        player.setGliding(false);
        player.getInventory().setChestplate(null);
        protectedUntil.put(id, System.currentTimeMillis() + 8000L);
        StartPack pack = pendingPack.remove(id);
        if (pack != null) {
            pack.give(player);
            Text.send(player, "&7You equipped your &f" + pack.display() + "&7.");
        }
        player.showTitle(Title.title(Text.plain("&a&lGOOD LUCK!"), Text.plain("&7Find loot in the chests"),
                Title.Times.times(Duration.ZERO, Duration.ofSeconds(2), Duration.ofMillis(500))));
    }

    // ------------------------------------------------------------------ the map: chests and bots

    private Location randomSurface(double fraction) {
        World world = arena();
        WorldBorder border = world.getWorldBorder();
        Location center = border.getCenter();
        double half = border.getSize() / 2.0 * fraction;
        for (int attempt = 0; attempt < 8; attempt++) {
            int x = (int) Math.floor(center.getX() + (random.nextDouble() * 2 - 1) * half);
            int z = (int) Math.floor(center.getZ() + (random.nextDouble() * 2 - 1) * half);
            int y = world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
            Block ground = world.getBlockAt(x, y, z);
            if (ground.isLiquid() || ground.getType().isAir()) {
                continue;
            }
            Block above = world.getBlockAt(x, y + 1, z);
            if (!above.getType().isAir()) {
                continue;
            }
            return new Location(world, x, y + 1, z);
        }
        return null;
    }

    private Location placeChest(LootTable.ChestType type) {
        Location location = randomSurface(type == LootTable.ChestType.SUPPLY ? 0.8 : 0.95);
        if (location == null) {
            return null;
        }
        Block block = location.getBlock();
        block.setType(Material.CHEST, false);
        if (block.getState() instanceof Chest chest) {
            LootTable.fill(chest.getBlockInventory(), random, type, plugin.events().lootFrenzy());
        }
        chests.add(block.getLocation());
        return block.getLocation();
    }

    private void supplyDrop() {
        Location location = placeChest(LootTable.ChestType.SUPPLY);
        if (location == null) {
            return;
        }
        PlayerUtil.celebrate(location);
        broadcast("&6&l\u2605 SUPPLY DROP! &7Legendary loot at &fX " + location.getBlockX() + " &7Z &f" + location.getBlockZ());
        for (UUID id : alive) {
            Player p = Bukkit.getPlayer(id);
            if (p != null) {
                PlayerUtil.play(p, "block.note_block.bell", 1f, 1.2f);
            }
        }
    }

    private void spawnBot() {
        Location location = randomSurface(0.9);
        if (location == null || state != State.RUNNING) {
            return;
        }
        String name = BOT_NAMES[random.nextInt(BOT_NAMES.length)] + (random.nextInt(90) + 10);
        boolean skeleton = random.nextInt(100) < 40;
        Mob bot;
        if (skeleton) {
            bot = arena().spawn(location, Skeleton.class, s -> setupBot(s, name, true));
        } else {
            bot = arena().spawn(location, Zombie.class, z -> {
                z.setBaby(false);
                setupBot(z, name, false);
            });
        }
        bots.add(bot.getUniqueId());
        botNames.put(bot.getUniqueId(), name);
    }

    private void setupBot(Mob mob, String name, boolean skeleton) {
        mob.customName(Text.plain("&c\u2694 Bot " + name));
        mob.setCustomNameVisible(true);
        mob.setCanPickupItems(false);
        mob.setRemoveWhenFarAway(false);
        mob.setPersistent(true);

        EntityEquipment equipment = mob.getEquipment();
        if (equipment == null) {
            return;
        }
        int roll = random.nextInt(100);
        int tier = roll < 40 ? 0 : roll < 70 ? 1 : roll < 90 ? 2 : 3;
        Material[][] armor = {
                {Material.LEATHER_HELMET, Material.LEATHER_CHESTPLATE, Material.LEATHER_LEGGINGS, Material.LEATHER_BOOTS},
                {Material.CHAINMAIL_HELMET, Material.CHAINMAIL_CHESTPLATE, Material.CHAINMAIL_LEGGINGS, Material.CHAINMAIL_BOOTS},
                {Material.IRON_HELMET, Material.IRON_CHESTPLATE, Material.IRON_LEGGINGS, Material.IRON_BOOTS},
                {Material.DIAMOND_HELMET, Material.DIAMOND_CHESTPLATE, Material.DIAMOND_LEGGINGS, Material.DIAMOND_BOOTS}};
        Material[] swords = {Material.WOODEN_SWORD, Material.STONE_SWORD, Material.IRON_SWORD, Material.DIAMOND_SWORD};
        // every bot gets a helmet so it does not burn in the sun
        equipment.setHelmet(new ItemStack(armor[tier][0]));
        if (tier >= 1 || random.nextBoolean()) {
            equipment.setChestplate(new ItemStack(armor[tier][1]));
        }
        if (tier >= 2) {
            equipment.setLeggings(new ItemStack(armor[tier][2]));
            equipment.setBoots(new ItemStack(armor[tier][3]));
        }
        equipment.setItemInMainHand(new ItemStack(skeleton ? Material.BOW : swords[tier]));
    }

    private void botTick() {
        WorldBorder border = arena().getWorldBorder();
        for (UUID id : new ArrayList<>(bots)) {
            Entity entity = Bukkit.getEntity(id);
            if (!(entity instanceof Mob mob) || !mob.isValid()) {
                int missing = botMissing.merge(id, 1, Integer::sum);
                if (missing >= 6) {
                    bots.remove(id);
                    botNames.remove(id);
                    botMissing.remove(id);
                }
                continue;
            }
            botMissing.remove(id);
            if (!border.isInside(mob.getLocation())) {
                mob.damage(3.0);
            }
            LivingEntity best = null;
            double bestDistance = 24.0 * 24.0;
            for (Entity near : mob.getNearbyEntities(24, 12, 24)) {
                boolean target = (near instanceof Player p && alive.contains(p.getUniqueId()) && !gliding.contains(p.getUniqueId()))
                        || bots.contains(near.getUniqueId());
                if (!target || !(near instanceof LivingEntity living)) {
                    continue;
                }
                double distance = near.getLocation().distanceSquared(mob.getLocation());
                if (distance < bestDistance) {
                    bestDistance = distance;
                    best = living;
                }
            }
            if (best != null) {
                mob.setTarget(best);
            }
        }
        checkEnd();
    }

    // ------------------------------------------------------------------ the match clock

    private void tickSecond() {
        if (state != State.RUNNING) {
            return;
        }
        elapsed++;
        WorldBorder border = arena().getWorldBorder();

        if (phase < WAIT.length) {
            phaseTimer--;
            if (!shrinking) {
                if (phaseTimer <= 0) {
                    shrinking = true;
                    phaseTimer = SHRINK[phase];
                    startSize = currentSize;
                    targetSize = initialSize * FRACTION[phase];
                    broadcast("&c&lTHE STORM IS CLOSING IN! &7Move to the safe zone.");
                    for (UUID id : alive) {
                        Player p = Bukkit.getPlayer(id);
                        if (p != null) {
                            PlayerUtil.play(p, "entity.wither.spawn", 0.4f, 1.5f);
                        }
                    }
                }
            } else {
                double t = 1.0 - Math.max(0, phaseTimer) / (double) SHRINK[phase];
                currentSize = startSize + (targetSize - startSize) * t;
                border.setSize(Math.max(2.0, currentSize));
                if (phaseTimer <= 0) {
                    shrinking = false;
                    phase++;
                    if (phase < WAIT.length) {
                        phaseTimer = WAIT[phase];
                        broadcast("&e&lThe storm has stopped. &7Next closing in &f" + phaseTimer + "s");
                    } else {
                        broadcast("&4&lFINAL ZONE! &7Only one can win.");
                    }
                }
            }
        }

        supplyTimer--;
        if (supplyTimer <= 0) {
            supplyTimer = Math.max(30, plugin.getConfig().getInt("arena.supply-interval", 120));
            supplyDrop();
        }
        if (elapsed % 2 == 0) {
            botTick();
        }
    }

    // ------------------------------------------------------------------ combat

    public boolean isAlive(Player player) {
        return state == State.RUNNING && alive.contains(player.getUniqueId());
    }

    public boolean isInMatch(Player player) {
        return (state == State.RUNNING || state == State.ENDING) && participants.contains(player.getUniqueId());
    }

    public boolean isBot(UUID id) {
        return bots.contains(id);
    }

    public String botName(UUID id) {
        return botNames.getOrDefault(id, "Bot");
    }

    public int aliveTotal() {
        return alive.size() + bots.size();
    }

    public boolean canDamage(Player victim, Player attacker) {
        UUID id = victim.getUniqueId();
        if (state != State.RUNNING || !alive.contains(id) || gliding.contains(id)) {
            return false;
        }
        Long until = protectedUntil.get(id);
        if (until != null && System.currentTimeMillis() < until) {
            return false;
        }
        return attacker == null || alive.contains(attacker.getUniqueId());
    }

    public void recordAttack(Player victim, Player attacker) {
        lastAttacker.put(victim.getUniqueId(), attacker.getUniqueId());
        lastAttackTime.put(victim.getUniqueId(), System.currentTimeMillis());
        lastBotAttacker.remove(victim.getUniqueId());
    }

    public void recordBotAttack(Player victim, String botName) {
        lastBotAttacker.put(victim.getUniqueId(), botName);
        lastAttackTime.put(victim.getUniqueId(), System.currentTimeMillis());
        lastAttacker.remove(victim.getUniqueId());
    }

    /** A player would die. */
    public void onLethal(Player victim) {
        UUID id = victim.getUniqueId();
        Long time = lastAttackTime.get(id);
        boolean recent = time != null && System.currentTimeMillis() - time < 10_000L;
        Player killer = null;
        String botCause = null;
        if (recent) {
            UUID killerId = lastAttacker.get(id);
            if (killerId != null) {
                killer = Bukkit.getPlayer(killerId);
            }
            botCause = lastBotAttacker.get(id);
        }
        eliminate(victim, killer, botCause, false);
    }

    private void eliminate(Player victim, Player killer, String botCause, boolean quit) {
        UUID id = victim.getUniqueId();
        if (!alive.remove(id)) {
            return;
        }
        gliding.remove(id);
        pendingPack.remove(id);
        int placement = alive.size() + bots.size() + 1;
        Location location = victim.getLocation();

        for (ItemStack stack : victim.getInventory().getContents()) {
            if (stack != null && stack.getType() != Material.ELYTRA && !stack.getType().isAir()) {
                location.getWorld().dropItemNaturally(location, stack);
            }
        }
        victim.getInventory().clear();

        String message;
        if (killer != null && !killer.equals(victim) && alive.contains(killer.getUniqueId())) {
            killsPlayers.merge(killer.getUniqueId(), 1, Integer::sum);
            Cosmetic fx = Cosmetics.get(plugin.data().get(killer).killFx);
            if (fx != null && plugin.data().get(killer).owned.contains(fx.id())) {
                Effects.killEffect(fx.data(), location);
            }
            message = "&c" + victim.getName() + " &7was eliminated by &f" + killer.getName();
            PlayerUtil.play(killer, "entity.player.levelup", 0.6f, 1.6f);
        } else if (botCause != null) {
            message = "&c" + victim.getName() + " &7was eliminated by &cBot " + botCause;
        } else {
            message = "&c" + victim.getName() + " &7was eliminated";
        }
        broadcast(message + " &8(" + aliveTotal() + " left)");

        if (!quit && victim.isOnline()) {
            PlayerUtil.revive(victim);
            victim.setGameMode(GameMode.SPECTATOR);
            giveRewards(victim, placement);
            victim.showTitle(Title.title(Text.plain("&c&lELIMINATED"), Text.plain("&7You placed &f#" + placement),
                    Title.Times.times(Duration.ZERO, Duration.ofSeconds(3), Duration.ofMillis(500))));
            Text.send(victim, "&7You can spectate, or use &b/lobby &7to leave.");
        }
        checkEnd();
    }

    /** A bot was killed. */
    public void onBotDeath(UUID botId, Player killer) {
        if (!bots.remove(botId)) {
            return;
        }
        botNames.remove(botId);
        if (killer != null && alive.contains(killer.getUniqueId())) {
            killsBots.merge(killer.getUniqueId(), 1, Integer::sum);
            PlayerUtil.play(killer, "entity.experience_orb.pickup", 1f, 1f);
        }
        checkEnd();
    }

    /** What a bot drops: its own gear (sometimes) plus a small bonus item. */
    public List<ItemStack> botDrops(Mob mob) {
        List<ItemStack> drops = new ArrayList<>();
        EntityEquipment equipment = mob.getEquipment();
        if (equipment != null) {
            for (ItemStack armor : equipment.getArmorContents()) {
                if (armor != null && !armor.getType().isAir() && random.nextBoolean()) {
                    drops.add(armor.clone());
                }
            }
            ItemStack hand = equipment.getItemInMainHand();
            if (!hand.getType().isAir() && random.nextBoolean()) {
                drops.add(hand.clone());
            }
        }
        drops.add(LootTable.botBonus(random));
        return drops;
    }

    private void checkEnd() {
        if (state != State.RUNNING) {
            return;
        }
        if (alive.isEmpty()) {
            end(null);
        } else if (alive.size() == 1 && bots.isEmpty()) {
            Player winner = Bukkit.getPlayer(alive.iterator().next());
            end(winner);
        }
    }

    // ------------------------------------------------------------------ rewards

    private void giveRewards(Player player, int placement) {
        UUID id = player.getUniqueId();
        PlayerData data = plugin.data().get(player);
        int kp = killsPlayers.getOrDefault(id, 0);
        int kb = killsBots.getOrDefault(id, 0);

        int placeCoins = placement == 1 ? 150 : placement == 2 ? 90 : placement == 3 ? 60 : placement <= 5 ? 40 : placement <= 10 ? 25 : 0;
        int placeXp = placement == 1 ? 200 : placement == 2 ? 120 : placement == 3 ? 90 : placement <= 5 ? 70 : placement <= 10 ? 50 : 20;
        double scale = botMatch ? plugin.getConfig().getDouble("bots.reward-multiplier", 0.5) : 1.0;
        int coinMult = plugin.events().coinMultiplier(data);
        int xpMult = plugin.events().xpMultiplier(data);

        long coins = Math.round((10 + placeCoins + kp * 12 + kb * 5) * scale) * coinMult;
        long xp = Math.round((30 + placeXp + kp * 20 + kb * 8) * scale) * xpMult;

        data.coins += coins;
        data.games++;
        data.kills += kp + kb;
        if (placement == 1) {
            data.wins++;
        } else {
            data.deaths++;
        }
        plugin.data().addXp(player, xp);

        player.sendMessage(Text.plain("&8&m                                    "));
        player.sendMessage(Text.plain("&6&lMATCH RESULTS &8- &7Placed &f#" + placement));
        player.sendMessage(Text.plain("&7Eliminations: &f" + kp + " &7players, &f" + kb + " &7bots"));
        player.sendMessage(Text.plain("&6+" + coins + " coins &8| &d+" + xp + " Battle Pass XP"
                + (coinMult > 1 || xpMult > 1 ? " &a(boosted!)" : "")));
        if (botMatch) {
            player.sendMessage(Text.plain("&8Bot match: rewards are reduced. Play with real players for full rewards!"));
        }
        player.sendMessage(Text.plain("&8&m                                    "));
    }

    // ------------------------------------------------------------------ ending

    private void end(Player winner) {
        if (state != State.RUNNING) {
            return;
        }
        state = State.ENDING;
        cancelTask(mainTask);
        cancelTask(landingTask);
        cancelTask(setupTask);
        mainTask = null;
        landingTask = null;
        setupTask = null;

        for (UUID id : new ArrayList<>(bots)) {
            Entity entity = Bukkit.getEntity(id);
            if (entity != null) {
                entity.remove();
            }
        }
        bots.clear();
        botNames.clear();

        if (winner != null) {
            alive.remove(winner.getUniqueId());
            giveRewards(winner, 1);
            PlayerUtil.celebrate(winner.getLocation());
            winner.showTitle(Title.title(Text.plain("&6&l\u2605 VICTORY ROYALE \u2605"), Text.plain("&7You are the last one standing!"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(5), Duration.ofMillis(800))));
            broadcast("&6&l" + winner.getName() + " &e&lWON THE MATCH!");
        } else {
            broadcast("&7The match ended with no winner.");
        }
        Bukkit.getScheduler().runTaskLater(plugin, this::cleanup, 200L);
    }

    private static void cancelTask(BukkitRunnable task) {
        if (task != null) {
            task.cancel();
        }
    }

    private void cleanup() {
        for (UUID id : new ArrayList<>(participants)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                plugin.toLobby(player);
            }
        }
        removeLeftovers();
        participants.clear();
        alive.clear();
        gliding.clear();
        pendingPack.clear();
        killsPlayers.clear();
        killsBots.clear();
        protectedUntil.clear();
        state = State.WAITING;
        botMatch = false;
        if (!queue.isEmpty()) {
            startWaiting();
        }
    }

    private void removeLeftovers() {
        for (Location location : chests) {
            Block block = location.getBlock();
            if (block.getType() == Material.CHEST) {
                block.setType(Material.AIR, false);
            }
        }
        chests.clear();
        for (Item item : arena().getEntitiesByClass(Item.class)) {
            item.remove();
        }
        arena().getWorldBorder().reset();
    }

    /** Stops everything (used on shutdown or by admins). */
    public void shutdown() {
        cancelQueueTasks();
        cancelTask(mainTask);
        cancelTask(landingTask);
        cancelTask(setupTask);
        mainTask = null;
        landingTask = null;
        setupTask = null;
        for (UUID id : new ArrayList<>(bots)) {
            Entity entity = Bukkit.getEntity(id);
            if (entity != null) {
                entity.remove();
            }
        }
        bots.clear();
        botNames.clear();
        for (UUID id : new ArrayList<>(participants)) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                plugin.toLobby(player);
            }
        }
        removeLeftovers();
        participants.clear();
        alive.clear();
        gliding.clear();
        queue.clear();
        state = State.WAITING;
    }

    /** The player left the match, queue or server. */
    public void handleQuit(Player player) {
        UUID id = player.getUniqueId();
        queue.remove(id);
        if (queue.isEmpty() && (state == State.WAITING || state == State.COUNTDOWN)) {
            cancelQueueTasks();
        }
        if (state == State.RUNNING && alive.contains(id)) {
            eliminate(player, null, null, true);
        }
    }

    // ------------------------------------------------------------------ text

    private void broadcast(String message) {
        for (UUID id : participants) {
            Player player = Bukkit.getPlayer(id);
            if (player != null) {
                Text.send(player, message);
            }
        }
    }

    public String statusText() {
        return switch (state) {
            case WAITING -> "&7Waiting for players";
            case COUNTDOWN -> "&eStarting in " + countdownLeft + "s";
            case RUNNING -> "&cIn progress (" + aliveTotal() + " alive)";
            case ENDING -> "&6Finishing";
        };
    }

    public List<String> sidebar(Player player) {
        List<String> lines = new ArrayList<>();
        UUID id = player.getUniqueId();
        if (isInMatch(player)) {
            lines.add("&7Alive: &f" + aliveTotal());
            lines.add("&7Kills: &a" + (killsPlayers.getOrDefault(id, 0) + killsBots.getOrDefault(id, 0)));
            if (gliding.contains(id)) {
                lines.add("&eGliding... find a landing spot!");
            } else if (phase >= WAIT.length) {
                lines.add("&4Final zone!");
            } else if (shrinking) {
                lines.add("&cStorm closing: &f" + Math.max(0, phaseTimer) + "s");
            } else {
                lines.add("&7Storm in: &f" + Math.max(0, phaseTimer) + "s");
            }
            lines.add("&7Zone size: &f" + (int) arena().getWorldBorder().getSize());
            if (!alive.contains(id)) {
                lines.add("&8Spectating");
            }
        } else if (queue.contains(id)) {
            lines.add("&aIn the queue &7(" + queue.size() + ")");
            lines.add(state == State.COUNTDOWN ? "&eStarting in &f" + countdownLeft + "s"
                    : (botsEnabled() ? "&7Bots join in &f" + Math.max(0, plugin.getConfig().getInt("bots.wait-seconds", 25) - waitSeconds) + "s"
                    : "&7Waiting for players"));
        }
        return lines;
    }
}
