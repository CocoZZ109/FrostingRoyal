package app.enderlab.frostingroyale;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.function.Supplier;

/** What is inside the chests. Items are named after their rarity colour. */
public final class LootTable {

    public enum ChestType { NORMAL, SUPPLY }

    private static final Map<Rarity, List<Supplier<ItemStack>>> POOLS = new EnumMap<>(Rarity.class);

    static {
        for (Rarity rarity : Rarity.values()) {
            POOLS.put(rarity, new ArrayList<>());
        }
        List<Supplier<ItemStack>> common = POOLS.get(Rarity.COMMON);
        common.add(() -> item(Material.WOODEN_SWORD, 1, Rarity.COMMON, "Wooden Sword"));
        common.add(() -> item(Material.LEATHER_HELMET, 1, Rarity.COMMON, "Leather Cap"));
        common.add(() -> item(Material.LEATHER_CHESTPLATE, 1, Rarity.COMMON, "Leather Tunic"));
        common.add(() -> item(Material.LEATHER_LEGGINGS, 1, Rarity.COMMON, "Leather Pants"));
        common.add(() -> item(Material.LEATHER_BOOTS, 1, Rarity.COMMON, "Leather Boots"));
        common.add(() -> item(Material.BREAD, 5, Rarity.COMMON, "Bread"));
        common.add(() -> item(Material.APPLE, 3, Rarity.COMMON, "Apples"));
        common.add(() -> item(Material.COOKED_CHICKEN, 3, Rarity.COMMON, "Cooked Chicken"));
        common.add(() -> item(Material.ARROW, 8, Rarity.COMMON, "Arrows"));
        common.add(() -> item(Material.SNOWBALL, 16, Rarity.COMMON, "Snowballs"));

        List<Supplier<ItemStack>> uncommon = POOLS.get(Rarity.UNCOMMON);
        uncommon.add(() -> item(Material.STONE_SWORD, 1, Rarity.UNCOMMON, "Stone Sword"));
        uncommon.add(() -> item(Material.CHAINMAIL_HELMET, 1, Rarity.UNCOMMON, "Chain Coif"));
        uncommon.add(() -> item(Material.CHAINMAIL_CHESTPLATE, 1, Rarity.UNCOMMON, "Chain Vest"));
        uncommon.add(() -> item(Material.CHAINMAIL_LEGGINGS, 1, Rarity.UNCOMMON, "Chain Leggings"));
        uncommon.add(() -> item(Material.CHAINMAIL_BOOTS, 1, Rarity.UNCOMMON, "Chain Boots"));
        uncommon.add(() -> item(Material.BOW, 1, Rarity.UNCOMMON, "Hunting Bow"));
        uncommon.add(() -> item(Material.ARROW, 16, Rarity.UNCOMMON, "Arrow Bundle"));
        uncommon.add(() -> item(Material.COOKED_BEEF, 4, Rarity.UNCOMMON, "Steak"));
        uncommon.add(() -> item(Material.GOLDEN_CARROT, 4, Rarity.UNCOMMON, "Golden Carrots"));
        uncommon.add(() -> item(Material.SHIELD, 1, Rarity.UNCOMMON, "Round Shield"));

        List<Supplier<ItemStack>> rare = POOLS.get(Rarity.RARE);
        rare.add(() -> item(Material.IRON_SWORD, 1, Rarity.RARE, "Iron Sword"));
        rare.add(() -> item(Material.IRON_HELMET, 1, Rarity.RARE, "Iron Helm"));
        rare.add(() -> item(Material.IRON_CHESTPLATE, 1, Rarity.RARE, "Iron Chestplate"));
        rare.add(() -> item(Material.IRON_LEGGINGS, 1, Rarity.RARE, "Iron Greaves"));
        rare.add(() -> item(Material.IRON_BOOTS, 1, Rarity.RARE, "Iron Boots"));
        rare.add(() -> item(Material.CROSSBOW, 1, Rarity.RARE, "Crossbow"));
        rare.add(() -> item(Material.GOLDEN_APPLE, 2, Rarity.RARE, "Shield Apples"));
        rare.add(() -> item(Material.ENDER_PEARL, 1, Rarity.RARE, "Ender Pearl"));
        rare.add(() -> item(Material.ARROW, 24, Rarity.RARE, "Arrow Stack"));

        List<Supplier<ItemStack>> epic = POOLS.get(Rarity.EPIC);
        epic.add(() -> item(Material.DIAMOND_SWORD, 1, Rarity.EPIC, "Diamond Blade", "sharpness", 1));
        epic.add(() -> item(Material.DIAMOND_HELMET, 1, Rarity.EPIC, "Diamond Helm", "protection", 1));
        epic.add(() -> item(Material.DIAMOND_CHESTPLATE, 1, Rarity.EPIC, "Diamond Chestplate", "protection", 1));
        epic.add(() -> item(Material.DIAMOND_LEGGINGS, 1, Rarity.EPIC, "Diamond Greaves", "protection", 1));
        epic.add(() -> item(Material.DIAMOND_BOOTS, 1, Rarity.EPIC, "Diamond Boots", "protection", 1));
        epic.add(() -> item(Material.BOW, 1, Rarity.EPIC, "Power Bow", "power", 2));
        epic.add(() -> item(Material.CROSSBOW, 1, Rarity.EPIC, "Rapid Crossbow", "quick_charge", 1));
        epic.add(() -> item(Material.GOLDEN_APPLE, 3, Rarity.EPIC, "Big Shield Apples"));
        epic.add(() -> item(Material.ENDER_PEARL, 2, Rarity.EPIC, "Ender Pearls"));

        List<Supplier<ItemStack>> legendary = POOLS.get(Rarity.LEGENDARY);
        legendary.add(() -> item(Material.NETHERITE_SWORD, 1, Rarity.LEGENDARY, "Mythic Blade", "sharpness", 2));
        legendary.add(() -> item(Material.DIAMOND_CHESTPLATE, 1, Rarity.LEGENDARY, "Mythic Chestplate", "protection", 2, "unbreaking", 2));
        legendary.add(() -> item(Material.DIAMOND_LEGGINGS, 1, Rarity.LEGENDARY, "Mythic Greaves", "protection", 2));
        legendary.add(() -> item(Material.BOW, 1, Rarity.LEGENDARY, "Mythic Bow", "power", 4, "punch", 1));
        legendary.add(() -> item(Material.ENCHANTED_GOLDEN_APPLE, 1, Rarity.LEGENDARY, "Mythic Apple"));
        legendary.add(() -> item(Material.TOTEM_OF_UNDYING, 1, Rarity.LEGENDARY, "Second Chance"));
        legendary.add(() -> item(Material.ENDER_PEARL, 4, Rarity.LEGENDARY, "Ender Pearl Stack"));
    }

    private LootTable() {
    }

    private static ItemStack item(Material material, int amount, Rarity rarity, String name, Object... enchants) {
        ItemStack stack = new ItemStack(material, amount);
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) {
            return stack;
        }
        meta.displayName(Text.item(rarity.color() + name));
        for (int i = 0; i + 1 < enchants.length; i += 2) {
            Enchantment enchantment = Registry.ENCHANTMENT.get(NamespacedKey.minecraft((String) enchants[i]));
            if (enchantment != null) {
                meta.addEnchant(enchantment, (Integer) enchants[i + 1], true);
            }
        }
        stack.setItemMeta(meta);
        return stack;
    }

    private static Rarity pickRarity(Random random, ChestType type, boolean frenzy) {
        int[] weights;
        if (type == ChestType.SUPPLY) {
            weights = frenzy ? new int[]{0, 0, 25, 40, 35} : new int[]{0, 0, 40, 40, 20};
        } else {
            weights = frenzy ? new int[]{35, 30, 20, 10, 5} : new int[]{60, 25, 10, 4, 1};
        }
        int total = 0;
        for (int w : weights) {
            total += w;
        }
        int roll = random.nextInt(total);
        Rarity[] rarities = Rarity.values();
        for (int i = 0; i < weights.length; i++) {
            roll -= weights[i];
            if (roll < 0) {
                return rarities[i];
            }
        }
        return Rarity.COMMON;
    }

    public static ItemStack rollOne(Random random, ChestType type, boolean frenzy) {
        Rarity rarity = pickRarity(random, type, frenzy);
        List<Supplier<ItemStack>> pool = POOLS.get(rarity);
        return pool.get(random.nextInt(pool.size())).get();
    }

    public static void fill(Inventory inventory, Random random, ChestType type, boolean frenzy) {
        int count = (type == ChestType.SUPPLY ? 4 : 3) + random.nextInt(3);
        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inventory.getSize(); i++) {
            slots.add(i);
        }
        Collections.shuffle(slots, random);
        for (int i = 0; i < count && i < slots.size(); i++) {
            inventory.setItem(slots.get(i), rollOne(random, type, frenzy));
        }
    }

    /** A small bonus item dropped by bots. */
    public static ItemStack botBonus(Random random) {
        Rarity rarity = random.nextInt(4) == 0 ? Rarity.UNCOMMON : Rarity.COMMON;
        List<Supplier<ItemStack>> pool = POOLS.get(rarity);
        return pool.get(random.nextInt(pool.size())).get();
    }
}
