package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/** The operator-only /admin chest menus: events, match control, giveaways and server control. */
public final class AdminMenus {

    private static final Material PANE = Material.GRAY_STAINED_GLASS_PANE;

    private final FrostingRoyale plugin;

    public AdminMenus(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    private boolean denied(Player player) {
        if (!player.hasPermission("frostingroyale.admin")) {
            player.closeInventory();
            Text.send(player, "&cYou don't have permission to do that.");
            return true;
        }
        return false;
    }

    public void main(Player player) {
        if (denied(player)) {
            return;
        }
        Menu menu = new Menu("&c&lAdmin Panel", 3).fill(PANE);
        menu.set(10, Text.icon(Material.FIREWORK_ROCKET, "&d&lHost an Event",
                "&7Shop sales, FREE shop, double", "&7coins/XP and loot frenzies", "", "&eClick to open"), (p, c) -> events(p));
        menu.set(12, Text.icon(Material.COMPASS, "&b&lMatch Control",
                "&7Start or end matches, supply", "&7drops, map centre", "", "&eClick to open"), (p, c) -> match(p));
        menu.set(14, Text.icon(Material.GOLD_INGOT, "&6&lGiveaways",
                "&7Give coins or XP to everyone", "&7who is online", "", "&eClick to open"), (p, c) -> giveaway(p));
        menu.set(16, Text.icon(Material.REDSTONE_BLOCK, "&c&lServer Control",
                "&7Maintenance mode, shutdown", "&7and emergency stop", "", "&eClick to open"), (p, c) -> server(p));
        menu.set(22, Text.icon(Material.BARRIER, "&cClose"), (p, c) -> p.closeInventory());
        menu.open(player);
    }

    // ------------------------------------------------------------------ events

    public void events(Player player) {
        if (denied(player)) {
            return;
        }
        Menu menu = new Menu("&d&lHost an Event", 4).fill(PANE);

        menu.set(10, eventIcon(EventManager.Type.SALE, 25, "&a25% OFF Shop"), (p, c) -> duration(p, EventManager.Type.SALE, 25));
        menu.set(11, eventIcon(EventManager.Type.SALE, 50, "&a50% OFF Shop"), (p, c) -> duration(p, EventManager.Type.SALE, 50));
        menu.set(12, eventIcon(EventManager.Type.SALE, 75, "&a75% OFF Shop"), (p, c) -> duration(p, EventManager.Type.SALE, 75));
        menu.set(13, eventIcon(EventManager.Type.FREE_SHOP, 100, "&6&lFREE SHOP"), (p, c) -> duration(p, EventManager.Type.FREE_SHOP, 100));
        menu.set(14, eventIcon(EventManager.Type.DOUBLE_COINS, 2, "&6Double Coins"), (p, c) -> duration(p, EventManager.Type.DOUBLE_COINS, 2));
        menu.set(15, eventIcon(EventManager.Type.DOUBLE_XP, 2, "&dDouble XP"), (p, c) -> duration(p, EventManager.Type.DOUBLE_XP, 2));
        menu.set(16, eventIcon(EventManager.Type.LOOT_FRENZY, 1, "&e&lLoot Frenzy"), (p, c) -> duration(p, EventManager.Type.LOOT_FRENZY, 1));

        List<String> active = new ArrayList<>();
        for (EventManager.Active a : plugin.events().active()) {
            active.add("&e" + a.describe());
        }
        if (active.isEmpty()) {
            active.add("&7No events are running.");
        }
        menu.set(22, Text.icon(Material.PAPER, "&bRunning events", active));
        menu.set(31, Text.icon(Material.TNT, "&cEnd all events", "&7Stops every running event."), (p, c) -> {
            plugin.events().endAll();
            events(p);
        });
        menu.set(27, Text.icon(Material.ARROW, "&7Back"), (p, c) -> main(p));
        menu.open(player);
    }

    private org.bukkit.inventory.ItemStack eventIcon(EventManager.Type type, int value, String name) {
        return Text.icon(type.icon(), name, "&7" + type.description(), "", "&eClick to choose a duration");
    }

    private void duration(Player player, EventManager.Type type, int value) {
        if (denied(player)) {
            return;
        }
        Menu menu = new Menu("&dHow long?", 3).fill(PANE);
        int[] minutes = {15, 30, 60, 180, 360};
        String[] labels = {"15 minutes", "30 minutes", "1 hour", "3 hours", "6 hours"};
        for (int i = 0; i < minutes.length; i++) {
            int length = minutes[i];
            menu.set(10 + i, Text.icon(Material.CLOCK, "&e" + labels[i], "&7Starts " + (type == EventManager.Type.SALE ? value + "% " : "") + type.display(),
                    "", "&aClick to start the event"), (p, c) -> {
                plugin.events().start(type, value, length);
                events(p);
            });
        }
        menu.set(18, Text.icon(Material.ARROW, "&7Back"), (p, c) -> events(p));
        menu.open(player);
    }

    // ------------------------------------------------------------------ match control

    public void match(Player player) {
        if (denied(player)) {
            return;
        }
        RoyaleMatch match = plugin.match();
        Menu menu = new Menu("&b&lMatch Control", 3).fill(PANE);
        menu.set(4, Text.icon(Material.PAPER, "&bStatus", "&7" + match.statusText(), "&7In queue: &f" + match.queueSize(),
                "&7Map centre: &f" + (int) plugin.admin().centerX() + ", " + (int) plugin.admin().centerZ()));
        menu.set(10, Text.icon(Material.LIME_CONCRETE, "&a&lForce start", "&7Starts the match now with", "&7everyone in the queue (bots fill in)."), (p, c) -> {
            if (!plugin.match().forceStart()) {
                Text.send(p, "&cNobody is in the queue, or a match is already running.");
            }
            match(p);
        });
        menu.set(12, Text.icon(Material.RED_CONCRETE, "&c&lForce end", "&7Ends the running match", "&7with no winner."), (p, c) -> {
            plugin.match().forceEnd();
            match(p);
        });
        menu.set(14, Text.icon(Material.CLOCK, "&e&lSkip phase", "&7Jumps to the next storm phase."), (p, c) -> {
            plugin.match().skipPhase();
            match(p);
        });
        menu.set(16, Text.icon(Material.CHEST, "&6&lSupply drop now", "&7Drops a legendary supply chest."), (p, c) -> {
            plugin.match().supplyDropNow();
            match(p);
        });
        menu.set(20, Text.icon(Material.MAP, "&f&lPre-generate the map", "&7Loads the map area in the", "&7background so matches start smoothly."), (p, c) -> {
            plugin.pregen(p);
            p.closeInventory();
        });
        menu.set(22, Text.icon(Material.COMPASS, "&b&lSet map centre here", "&7Uses your current position.", "&7Stand where you want the map middle.",
                "&8(Only works in the match world)"), (p, c) -> {
            p.closeInventory();
            plugin.setCenterFrom(p);
        });
        menu.set(24, Text.icon(Material.ENDER_PEARL, "&d&lGo to the match world", "&7Teleports you to the map centre", "&7so you can pick a good spot."), (p, c) -> {
            p.closeInventory();
            p.teleport(plugin.mapCenterSafe());
        });
        menu.set(18, Text.icon(Material.ARROW, "&7Back"), (p, c) -> main(p));
        menu.open(player);
    }

    // ------------------------------------------------------------------ giveaways

    public void giveaway(Player player) {
        if (denied(player)) {
            return;
        }
        Menu menu = new Menu("&6&lGiveaways", 3).fill(PANE);
        int[] amounts = {100, 250, 500, 1000, 2500};
        for (int i = 0; i < amounts.length; i++) {
            int amount = amounts[i];
            menu.set(10 + i, Text.icon(Material.GOLD_INGOT, amount, "&6" + amount + " coins for everyone",
                    List.of("&7Gives " + amount + " coins to every", "&7player who is online right now.", "", "&eClick to give")), (p, c) -> {
                for (Player online : Bukkit.getOnlinePlayers()) {
                    plugin.data().addCoins(online, amount);
                    online.sendMessage(Text.plain(Text.PREFIX + "&6&l\u2605 GIVEAWAY! &7Everyone received &6" + amount + " coins&7!"));
                    PlayerUtil.play(online, "entity.player.levelup", 1f, 1.2f);
                }
                giveaway(p);
            });
        }
        menu.set(16, Text.icon(Material.EXPERIENCE_BOTTLE, "&d+" + BattlePass.xpPerTier() + " Battle Pass XP for everyone",
                "&7Gives one tier worth of XP to", "&7every player who is online.", "", "&eClick to give"), (p, c) -> {
            for (Player online : Bukkit.getOnlinePlayers()) {
                plugin.data().addXp(online, BattlePass.xpPerTier());
                online.sendMessage(Text.plain(Text.PREFIX + "&d&l\u2605 GIVEAWAY! &7Everyone received a Battle Pass tier of XP!"));
            }
            giveaway(p);
        });
        menu.set(18, Text.icon(Material.ARROW, "&7Back"), (p, c) -> main(p));
        menu.open(player);
    }

    // ------------------------------------------------------------------ server control

    public void server(Player player) {
        if (denied(player)) {
            return;
        }
        AdminActions admin = plugin.admin();
        Menu menu = new Menu("&cServer Control", 3).fill(PANE);
        boolean on = admin.maintenance();
        menu.set(10, Text.icon(on ? Material.LIME_DYE : Material.GRAY_DYE, on ? "&aMaintenance mode: ON" : "&7Maintenance mode: OFF",
                "&7When on, only operators can join.", "&7Turning it on kicks everyone else.", "", "&eClick to toggle"), (p, c) -> {
            admin.setMaintenance(!admin.maintenance());
            server(p);
        });
        menu.set(11, Text.icon(Material.CLOCK, "&6Shutdown in 60 seconds", "&7Warns everyone, saves, then stops."), (p, c) -> {
            admin.scheduleShutdown(60, "maintenance");
            p.closeInventory();
        });
        menu.set(12, Text.icon(Material.CLOCK, 5, "&6Shutdown in 5 minutes", List.of("&7Same, with a longer warning.")), (p, c) -> {
            admin.scheduleShutdown(300, "maintenance");
            p.closeInventory();
        });
        menu.set(13, Text.icon(Material.BARRIER, "&aCancel scheduled shutdown",
                admin.shutdownScheduled() ? "&7A shutdown is scheduled." : "&7No shutdown is scheduled."), (p, c) -> {
            admin.cancelShutdown();
            server(p);
        });
        menu.set(15, Text.icon(Material.TNT, "&4&lEmergency stop NOW", "&7Saves everything, kicks all players", "&7and stops the server at once.",
                "&7Use this for crashes.", "", "&eClick (asks to confirm)"), (p, c) -> confirmStop(p));
        menu.set(22, Text.icon(Material.ARROW, "&7Back"), (p, c) -> main(p));
        menu.open(player);
    }

    private void confirmStop(Player player) {
        Menu menu = new Menu("&4Stop the server now?", 3).fill(PANE);
        menu.set(11, Text.icon(Material.LIME_CONCRETE, "&a&lYES - stop now", "&7Everyone will be kicked."), (p, c) -> {
            if (!denied(p)) {
                plugin.admin().stopNow("emergency stop");
            }
        });
        menu.set(15, Text.icon(Material.RED_CONCRETE, "&c&lNO - go back"), (p, c) -> server(p));
        menu.open(player);
    }
}
