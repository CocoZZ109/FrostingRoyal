package app.enderlab.frostingroyale;

import org.bukkit.Material;

/**
 * Something cosmetic you can own. data is: particle name(s) for trails (comma separated, first one that
 * exists is used), an effect key for kill effects, or the text shown before your name for titles.
 */
public record Cosmetic(String id, CosmeticType type, String name, Material icon, Rarity rarity,
                       boolean passOnly, String data) {
}
