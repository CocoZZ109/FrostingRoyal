package app.enderlab.frostingroyale;

import java.util.HashMap;
import java.util.Map;

/** The Winter Royale Battle Pass: 30 tiers with a free and a premium reward track. */
public final class BattlePass {

    public static final int TIERS = 30;
    public static final String SEASON = "Winter Royale";

    private static final Map<Integer, Reward> FREE = new HashMap<>();
    private static final Map<Integer, Reward> PREMIUM = new HashMap<>();

    static {
        FREE.put(1, Reward.coins(50));
        FREE.put(3, Reward.cosmetic("trail_snow"));
        FREE.put(5, Reward.coins(100));
        FREE.put(8, Reward.pack(StartPack.SCAVENGER, 3));
        FREE.put(10, Reward.cosmetic("title_rookie"));
        FREE.put(12, Reward.coins(100));
        FREE.put(15, Reward.cosmetic("fx_snow"));
        FREE.put(18, Reward.coins(150));
        FREE.put(20, Reward.pack(StartPack.WARRIOR, 3));
        FREE.put(23, Reward.cosmetic("title_lucky"));
        FREE.put(25, Reward.coins(200));
        FREE.put(28, Reward.coins(250));
        FREE.put(30, Reward.coins(300));

        for (int tier = 1; tier <= TIERS; tier++) {
            PREMIUM.put(tier, Reward.coins(100));
        }
        PREMIUM.put(2, Reward.cosmetic("trail_frost"));
        PREMIUM.put(4, Reward.pack(StartPack.MEDIC, 3));
        PREMIUM.put(5, Reward.cosmetic("title_premium"));
        PREMIUM.put(7, Reward.cosmetic("fx_candy"));
        PREMIUM.put(10, Reward.cosmetic("trail_aura"));
        PREMIUM.put(13, Reward.pack(StartPack.WARRIOR, 5));
        PREMIUM.put(15, Reward.cosmetic("title_elite"));
        PREMIUM.put(20, Reward.cosmetic("fx_royale"));
        PREMIUM.put(25, Reward.cosmetic("title_passmaster"));
        PREMIUM.put(30, Reward.coins(750));
    }

    private BattlePass() {
    }

    public static Reward free(int tier) {
        return FREE.get(tier);
    }

    public static Reward premium(int tier) {
        return PREMIUM.get(tier);
    }

    public static int xpPerTier() {
        return Math.max(10, FrostingRoyale.get().getConfig().getInt("battle-pass.xp-per-tier", 100));
    }

    public static int premiumPrice() {
        return Math.max(0, FrostingRoyale.get().getConfig().getInt("battle-pass.premium-price", 2500));
    }

    public static int tierSkipPrice() {
        return Math.max(0, FrostingRoyale.get().getConfig().getInt("battle-pass.tier-skip-price", 250));
    }

    public static int level(PlayerData data) {
        return (int) Math.min(TIERS, data.xp / xpPerTier());
    }

    public static int xpIntoTier(PlayerData data) {
        if (level(data) >= TIERS) {
            return xpPerTier();
        }
        return (int) (data.xp % xpPerTier());
    }
}
