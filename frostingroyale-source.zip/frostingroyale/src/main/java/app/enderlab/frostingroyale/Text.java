package app.enderlab.frostingroyale;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

/** Small helpers for colored text and menu items. Colors use & codes. */
public final class Text {

    public static final String PREFIX = "&6&lRoyale &8\u00BB &7";

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private Text() {
    }

    /** Colored text for chat, titles and inventory titles. */
    public static Component plain(String text) {
        return LEGACY.deserialize(text);
    }

    /** Colored text for item names and lore (italics switched off). */
    public static Component item(String text) {
        return LEGACY.deserialize(text).decoration(TextDecoration.ITALIC, false);
    }

    public static void send(CommandSender sender, String message) {
        sender.sendMessage(plain(PREFIX + message));
    }

    public static ItemStack icon(Material material, String name, String... lore) {
        return icon(material, 1, name, List.of(lore));
    }

    public static ItemStack icon(Material material, String name, List<String> lore) {
        return icon(material, 1, name, lore);
    }

    public static ItemStack icon(Material material, int amount, String name, List<String> lore) {
        ItemStack stack = new ItemStack(material, Math.max(1, amount));
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.displayName(item(name));
            List<Component> lines = new ArrayList<>();
            for (String line : lore) {
                lines.add(item(line));
            }
            meta.lore(lines);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    public static String duration(long seconds) {
        long m = seconds / 60L;
        long s = seconds % 60L;
        return m + "m " + s + "s";
    }
}
