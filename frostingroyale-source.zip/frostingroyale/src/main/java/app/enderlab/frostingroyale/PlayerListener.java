package app.enderlab.frostingroyale;

import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.time.Duration;

public final class PlayerListener implements Listener {

    private final FrostingRoyale plugin;

    public PlayerListener(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onLogin(PlayerLoginEvent event) {
        if (plugin.admin().maintenance() && !AdminActions.canBypass(event.getPlayer())) {
            event.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                    Text.plain("&6&lFrostingRoyale\n&7The server is in maintenance mode.\n&7Please come back soon!"));
        }
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        event.joinMessage(Text.plain("&8[&a+&8] &7" + player.getName()));
        plugin.toLobby(player);

        player.showTitle(Title.title(Text.plain("&6&lFROSTING ROYALE"), Text.plain("&7Drop in. Loot up. Be the last one standing."),
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(800))));
        PlayerUtil.play(player, "entity.player.levelup", 0.6f, 1.4f);

        var events = plugin.events().active();
        for (EventManager.Active active : events) {
            Text.send(player, "&6&l\u2605 EVENT: &e" + active.describe());
        }
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline() && plugin.lobby().equals(player.getWorld())) {
                plugin.menus().play(player);
            }
        }, 20L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        event.quitMessage(Text.plain("&8[&c-&8] &7" + player.getName()));
        plugin.match().handleQuit(player);
        plugin.sidebar().remove(player);
        plugin.data().save();
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        // normal eliminations are handled before death; this is a safety net (e.g. /kill)
        event.getDrops().clear();
        event.deathMessage(null);
        event.setShouldDropExperience(false);
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        Player player = event.getPlayer();
        event.setRespawnLocation(plugin.lobbySpawn());
        Bukkit.getScheduler().runTaskLater(plugin, () -> plugin.toLobby(player), 1L);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!player.getWorld().equals(plugin.lobby())) {
            return;
        }
        Action action = event.getAction();
        boolean right = action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK;
        ItemStack item = event.getItem();

        if (right && event.getHand() == EquipmentSlot.HAND && item != null) {
            ItemMeta meta = item.getItemMeta();
            String id = meta == null ? null
                    : meta.getPersistentDataContainer().get(plugin.itemKey(), PersistentDataType.STRING);
            if (id != null) {
                event.setCancelled(true);
                switch (id) {
                    case "play" -> plugin.menus().play(player);
                    case "shop" -> plugin.menus().itemShop(player);
                    case "pass" -> plugin.menus().pass(player, 0);
                    case "locker" -> plugin.menus().locker(player);
                    case "stats" -> plugin.menus().stats(player);
                    default -> {
                    }
                }
                return;
            }
        }
        if (action == Action.RIGHT_CLICK_BLOCK
                && !(player.getGameMode() == GameMode.CREATIVE && player.hasPermission("frostingroyale.admin"))) {
            event.setCancelled(true);
        }
    }
}
