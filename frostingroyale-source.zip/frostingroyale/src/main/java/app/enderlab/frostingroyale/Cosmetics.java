package app.enderlab.frostingroyale;

import org.bukkit.Material;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** The catalog of every cosmetic. passOnly ones can only be earned in the Battle Pass. */
public final class Cosmetics {

    private static final Map<String, Cosmetic> ALL = new LinkedHashMap<>();

    static {
        // trails
        trail("trail_snow", "Snowfall", Material.SNOWBALL, Rarity.COMMON, false, "SNOWFLAKE");
        trail("trail_cloud", "Cloud Nine", Material.WHITE_WOOL, Rarity.COMMON, false, "CLOUD");
        trail("trail_sparks", "Sparks", Material.FLINT_AND_STEEL, Rarity.COMMON, false, "CRIT");
        trail("trail_flame", "Blazing", Material.BLAZE_POWDER, Rarity.UNCOMMON, false, "FLAME");
        trail("trail_notes", "Melody", Material.NOTE_BLOCK, Rarity.UNCOMMON, false, "NOTE");
        trail("trail_lucky", "Lucky Charm", Material.EMERALD, Rarity.UNCOMMON, false, "HAPPY_VILLAGER,VILLAGER_HAPPY");
        trail("trail_hearts", "Lovestruck", Material.RED_DYE, Rarity.RARE, false, "HEART");
        trail("trail_stars", "Stardust", Material.END_ROD, Rarity.RARE, false, "END_ROD");
        trail("trail_magic", "Enchanted", Material.ENCHANTING_TABLE, Rarity.EPIC, false, "ENCHANT,ENCHANTMENT_TABLE");
        trail("trail_void", "Void Walker", Material.OBSIDIAN, Rarity.EPIC, false, "PORTAL");
        trail("trail_frost", "Frostbite", Material.PACKED_ICE, Rarity.EPIC, true, "SNOWFLAKE");
        trail("trail_aura", "Royale Aura", Material.NETHER_STAR, Rarity.LEGENDARY, true, "END_ROD");

        // kill effects
        killFx("fx_snow", "Snow Burst", Material.SNOW_BLOCK, Rarity.COMMON, false, "snow");
        killFx("fx_smoke", "Smoke Bomb", Material.GUNPOWDER, Rarity.COMMON, false, "smoke");
        killFx("fx_flames", "Inferno", Material.FIRE_CHARGE, Rarity.UNCOMMON, false, "flames");
        killFx("fx_hearts", "Heart Burst", Material.PINK_DYE, Rarity.UNCOMMON, false, "hearts");
        killFx("fx_firework", "Fireworks", Material.FIREWORK_ROCKET, Rarity.RARE, false, "firework");
        killFx("fx_lightning", "Thunderstrike", Material.LIGHTNING_ROD, Rarity.EPIC, false, "lightning");
        killFx("fx_candy", "Candy Pop", Material.SWEET_BERRIES, Rarity.EPIC, true, "firework");
        killFx("fx_royale", "Royale Burst", Material.TOTEM_OF_UNDYING, Rarity.LEGENDARY, true, "lightning");

        // titles
        title("title_rookie", "Rookie", Rarity.COMMON, false, "&7[Rookie]");
        title("title_lucky", "Lucky", Rarity.COMMON, false, "&a[Lucky]");
        title("title_frosty", "Frosty", Rarity.UNCOMMON, false, "&f[Frosty]");
        title("title_sweaty", "Sweaty", Rarity.UNCOMMON, false, "&b[Sweaty]");
        title("title_menace", "Menace", Rarity.RARE, false, "&c[Menace]");
        title("title_royale", "Royale", Rarity.EPIC, false, "&5[Royale]");
        title("title_champion", "Champion", Rarity.EPIC, false, "&6[Champion]");
        title("title_legend", "Legend", Rarity.LEGENDARY, false, "&d[Legend]");
        title("title_premium", "Premium", Rarity.RARE, true, "&e[Premium]");
        title("title_elite", "Elite", Rarity.EPIC, true, "&b[Elite]");
        title("title_passmaster", "Pass Master", Rarity.LEGENDARY, true, "&6&l[Pass Master]");
    }

    private Cosmetics() {
    }

    private static void trail(String id, String name, Material icon, Rarity rarity, boolean passOnly, String particles) {
        ALL.put(id, new Cosmetic(id, CosmeticType.TRAIL, name, icon, rarity, passOnly, particles));
    }

    private static void killFx(String id, String name, Material icon, Rarity rarity, boolean passOnly, String key) {
        ALL.put(id, new Cosmetic(id, CosmeticType.KILL_FX, name, icon, rarity, passOnly, key));
    }

    private static void title(String id, String name, Rarity rarity, boolean passOnly, String text) {
        ALL.put(id, new Cosmetic(id, CosmeticType.TITLE, name, Material.NAME_TAG, rarity, passOnly, text));
    }

    public static Cosmetic get(String id) {
        return id == null ? null : ALL.get(id);
    }

    public static List<Cosmetic> all() {
        return new ArrayList<>(ALL.values());
    }

    public static List<Cosmetic> ofType(CosmeticType type) {
        List<Cosmetic> list = new ArrayList<>();
        for (Cosmetic cosmetic : ALL.values()) {
            if (cosmetic.type() == type) {
                list.add(cosmetic);
            }
        }
        return list;
    }

    /** Cosmetics that can appear in the Item Shop. */
    public static List<Cosmetic> shopItems() {
        List<Cosmetic> list = new ArrayList<>();
        for (Cosmetic cosmetic : ALL.values()) {
            if (!cosmetic.passOnly()) {
                list.add(cosmetic);
            }
        }
        return list;
    }
}
