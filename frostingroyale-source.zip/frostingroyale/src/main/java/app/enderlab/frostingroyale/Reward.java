package app.enderlab.frostingroyale;

import org.bukkit.Material;

/** A Battle Pass reward: coins, a cosmetic, or start packs. */
public record Reward(Kind kind, String id, int amount) {

    public enum Kind { COINS, COSMETIC, PACK }

    public static Reward coins(int amount) {
        return new Reward(Kind.COINS, "coins", amount);
    }

    public static Reward cosmetic(String id) {
        return new Reward(Kind.COSMETIC, id, 1);
    }

    public static Reward pack(StartPack pack, int amount) {
        return new Reward(Kind.PACK, pack.id(), amount);
    }

    public String text() {
        switch (kind) {
            case COINS:
                return "&6" + amount + " Coins";
            case COSMETIC: {
                Cosmetic cosmetic = Cosmetics.get(id);
                return cosmetic == null ? "&7?" : cosmetic.rarity().color() + cosmetic.name() + " &7(" + cosmetic.type().display() + ")";
            }
            default: {
                StartPack pack = StartPack.byId(id);
                return "&f" + amount + "x " + (pack == null ? id : pack.display());
            }
        }
    }

    public Material icon() {
        switch (kind) {
            case COINS:
                return Material.GOLD_INGOT;
            case COSMETIC: {
                Cosmetic cosmetic = Cosmetics.get(id);
                return cosmetic == null ? Material.BARRIER : cosmetic.icon();
            }
            default: {
                StartPack pack = StartPack.byId(id);
                return pack == null ? Material.CHEST : pack.icon();
            }
        }
    }
}
