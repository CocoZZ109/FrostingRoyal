package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.Difficulty;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.List;

public final class FrostingRoyale extends JavaPlugin {

    public static final String LOBBY_WORLD = "frostingroyale_lobby";
    public static final String ARENA_WORLD = "frostingroyale_arena";

    private static FrostingRoyale instance;

    private World lobby;
    private World arena;
    private DataManager data;
    private EventManager events;
    private ShopManager shop;
    private RoyaleMatch match;
    private Menus menus;
    private AdminMenus adminMenus;
    private SidebarManager sidebar;
    private AdminActions admin;
    private NamespacedKey itemKey;
    private boolean pregenRunning;

    public static FrostingRoyale get() {
        return instance;
    }

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        itemKey = new NamespacedKey(this, "item");

        if (!createWorlds()) {
            getLogger().severe("Could not create the game worlds. Disabling FrostingRoyale.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        data = new DataManager(this);
        events = new EventManager(this);
        shop = new ShopManager(this);
        sidebar = new SidebarManager();
        admin = new AdminActions(this);
        match = new RoyaleMatch(this);
        menus = new Menus(this);
        adminMenus = new AdminMenus(this);

        getServer().getPluginManager().registerEvents(new MenuListener(), this);
        getServer().getPluginManager().registerEvents(new GameListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);

        RoyaleCommands commands = new RoyaleCommands(this);
        for (String name : new String[]{"play", "lobby", "shop", "pass", "locker", "stats", "coins", "admin"}) {
            PluginCommand command = getCommand(name);
            if (command != null) {
                command.setExecutor(commands);
                command.setTabCompleter(commands);
            }
        }

        if (!admin.lobbyBuilt()) {
            new LobbyBuilder(lobby).build();
            admin.setLobbyBuilt(true);
            getLogger().info("The lobby was built.");
        }

        startTasks();
        for (Player player : Bukkit.getOnlinePlayers()) {
            toLobby(player);
        }
        getLogger().info("FrostingRoyale is ready. Tip: stand in the match world and run /admin setcenter, then /admin pregen.");
    }

    @Override
    public void onDisable() {
        if (match != null) {
            try {
                match.shutdown();
            } catch (RuntimeException e) {
                getLogger().warning("Error while ending the match: " + e.getMessage());
            }
        }
        saveAll();
    }

    public void saveAll() {
        if (data != null) {
            data.save();
        }
    }

    // ------------------------------------------------------------------ worlds

    private boolean createWorlds() {
        WorldCreator lobbyCreator = new WorldCreator(LOBBY_WORLD);
        lobbyCreator.generator(new VoidGenerator());
        lobbyCreator.environment(World.Environment.NORMAL);
        lobbyCreator.generateStructures(false);
        World createdLobby = Bukkit.createWorld(lobbyCreator);

        WorldCreator arenaCreator = new WorldCreator(ARENA_WORLD);
        arenaCreator.environment(World.Environment.NORMAL);
        long seed = getConfig().getLong("arena.seed", 0L);
        if (seed != 0L) {
            arenaCreator.seed(seed);
        }
        World createdArena = Bukkit.createWorld(arenaCreator);

        if (createdLobby == null || createdArena == null) {
            return false;
        }
        lobby = createdLobby;
        arena = createdArena;
        lobby.setDifficulty(Difficulty.PEACEFUL);
        lobby.setStorm(false);
        lobby.setTime(6000L);
        lobby.setSpawnLocation(0, 65, 16);
        arena.setDifficulty(Difficulty.NORMAL);
        arena.setTime(6000L);
        return true;
    }

    public World lobby() {
        return lobby;
    }

    public World arena() {
        return arena;
    }

    public Location lobbySpawn() {
        return new Location(lobby, 0.5, 65.0, 16.5, 180f, 0f);
    }

    /** The middle of the battle royale map (set with /admin setcenter). */
    public Location mapCenter() {
        return new Location(arena, admin.centerX(), 100, admin.centerZ());
    }

    public Location mapCenterSafe() {
        int x = (int) Math.floor(admin.centerX());
        int z = (int) Math.floor(admin.centerZ());
        int y = arena.getHighestBlockYAt(x, z) + 2;
        return new Location(arena, x + 0.5, y, z + 0.5);
    }

    public void setCenterFrom(Player player) {
        if (!player.getWorld().equals(arena)) {
            Text.send(player, "&cStand in the match world first (Match Control > Go to the match world).");
            return;
        }
        admin.setCenter(player.getLocation().getX(), player.getLocation().getZ());
        Text.send(player, "&7The map centre is now &f" + player.getLocation().getBlockX() + ", " + player.getLocation().getBlockZ()
                + "&7. Run &b/admin pregen &7to prepare the map.");
    }

    /** Loads the whole map area in the background so matches start smoothly. requester may be null. */
    public void pregen(Player requester) {
        if (pregenRunning) {
            if (requester != null) {
                Text.send(requester, "&7Map pre-generation is already running.");
            }
            return;
        }
        pregenRunning = true;
        double size = Math.max(100, getConfig().getInt("arena.initial-size", 300));
        int radius = (int) Math.ceil((size / 2.0 + 64.0) / 16.0);
        int centerChunkX = (int) Math.floor(admin.centerX()) >> 4;
        int centerChunkZ = (int) Math.floor(admin.centerZ()) >> 4;
        List<int[]> chunks = new ArrayList<>();
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                chunks.add(new int[]{centerChunkX + dx, centerChunkZ + dz});
            }
        }
        if (requester != null) {
            Text.send(requester, "&7Pre-generating &f" + chunks.size() + " &7chunks in the background...");
        }
        new BukkitRunnable() {
            int index = 0;

            @Override
            public void run() {
                int done = 0;
                while (index < chunks.size() && done < 6) {
                    int[] c = chunks.get(index++);
                    arena.getChunkAtAsync(c[0], c[1]);
                    done++;
                }
                if (index >= chunks.size()) {
                    pregenRunning = false;
                    cancel();
                    if (requester != null && requester.isOnline()) {
                        Text.send(requester, "&aPre-generation requested for the whole map. It finishes in the background.");
                    }
                }
            }
        }.runTaskTimer(this, 1L, 2L);
    }

    // ------------------------------------------------------------------ lobby

    public void toLobby(Player player) {
        match.handleQuit(player);
        PlayerUtil.reset(player);
        player.setGameMode(GameMode.ADVENTURE);
        player.teleport(lobbySpawn());
        giveHotbar(player);
        data.refreshName(player);
    }

    private void giveHotbar(Player player) {
        player.getInventory().setItem(0, hotbarItem(Material.COMPASS, "&b&lPlay", "play", "&7Join a battle royale", "&eRight-click"));
        player.getInventory().setItem(1, hotbarItem(Material.EMERALD, "&a&lItem Shop", "shop", "&7Daily cosmetics", "&eRight-click"));
        player.getInventory().setItem(2, hotbarItem(Material.NETHER_STAR, "&e&lBattle Pass", "pass", "&7Tiers and rewards", "&eRight-click"));
        player.getInventory().setItem(4, hotbarItem(Material.ENDER_CHEST, "&d&lLocker", "locker", "&7Trails, effects, titles", "&eRight-click"));
        player.getInventory().setItem(6, hotbarItem(Material.BOOK, "&b&lStats", "stats", "&7Your stats", "&eRight-click"));
    }

    private ItemStack hotbarItem(Material material, String name, String id, String... lore) {
        ItemStack stack = Text.icon(material, name, lore);
        ItemMeta meta = stack.getItemMeta();
        if (meta != null) {
            meta.getPersistentDataContainer().set(itemKey, PersistentDataType.STRING, id);
            stack.setItemMeta(meta);
        }
        return stack;
    }

    // ------------------------------------------------------------------ tasks

    private void startTasks() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getWorld().equals(lobby) || player.getWorld().equals(arena)) {
                    updateSidebar(player);
                }
            }
        }, 20L, 20L);

        // cosmetic trails in the lobby and while gliding
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                PlayerData d = data.get(player);
                Cosmetic trail = Cosmetics.get(d.trail);
                if (trail == null || !d.owned.contains(trail.id())) {
                    continue;
                }
                boolean show = player.getWorld().equals(lobby) || (match.isAlive(player) && player.isGliding());
                if (show) {
                    Effects.trail(player, trail);
                }
            }
        }, 10L, 4L);

        // players who fall out of the lobby
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                if (player.getWorld().equals(lobby) && player.getLocation().getY() < 20.0) {
                    player.teleport(lobbySpawn());
                }
            }
        }, 10L, 10L);

        // fixed daytime and event clean-up
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            lobby.setTime(6000L);
            arena.setTime(6000L);
            events.prune();
        }, 200L, 200L);

        Bukkit.getScheduler().runTaskTimer(this, () -> data.save(), 6000L, 6000L);
    }

    private void updateSidebar(Player player) {
        PlayerData d = data.get(player);
        List<String> lines = new ArrayList<>();
        lines.add("&7Coins: &6" + d.coins);
        lines.add("&7Pass tier: &e" + BattlePass.level(d) + "&7/" + BattlePass.TIERS);

        List<String> matchLines = match.sidebar(player);
        if (!matchLines.isEmpty()) {
            lines.add("&8");
            lines.addAll(matchLines);
        } else {
            lines.add("&7Wins: &a" + d.wins + " &7Elims: &a" + d.kills);
            lines.add("&8");
            lines.add("&bUse the compass to play!");
        }
        int shown = 0;
        for (EventManager.Active active : events.active()) {
            if (shown >= 2 || lines.size() >= 9) {
                break;
            }
            lines.add("&d\u2605 " + active.describe());
            shown++;
        }
        sidebar.update(player, "&6&l\u2605 FROSTING ROYALE \u2605", lines);
    }

    // ------------------------------------------------------------------ accessors

    public DataManager data() {
        return data;
    }

    public EventManager events() {
        return events;
    }

    public ShopManager shop() {
        return shop;
    }

    public RoyaleMatch match() {
        return match;
    }

    public Menus menus() {
        return menus;
    }

    public AdminMenus adminMenus() {
        return adminMenus;
    }

    public SidebarManager sidebar() {
        return sidebar;
    }

    public AdminActions admin() {
        return admin;
    }

    public NamespacedKey itemKey() {
        return itemKey;
    }
}
