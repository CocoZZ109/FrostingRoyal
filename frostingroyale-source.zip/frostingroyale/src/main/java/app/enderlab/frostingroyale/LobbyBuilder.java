package app.enderlab.frostingroyale;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Entity;

/** Builds the lobby island: a glowing plaza, a victory podium, a battle bus and floating signs. */
public final class LobbyBuilder {

    private static final int Y = 64;

    private final World world;

    public LobbyBuilder(World world) {
        this.world = world;
    }

    private void set(int x, int y, int z, Material material) {
        world.getBlockAt(x, y, z).setType(material, false);
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                    set(x, y, z, material);
                }
            }
        }
    }

    private void holo(double x, double y, double z, String text) {
        world.spawn(new Location(world, x, y, z), ArmorStand.class, stand -> {
            stand.setVisible(false);
            stand.setGravity(false);
            stand.setMarker(true);
            stand.setInvulnerable(true);
            stand.setPersistent(true);
            stand.customName(Text.plain(text));
            stand.setCustomNameVisible(true);
        });
    }

    public void build() {
        // remove old floating text so it never doubles up
        for (Entity entity : world.getEntities()) {
            if (entity instanceof ArmorStand) {
                entity.remove();
            }
        }

        int radius = 28;
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dz = -radius; dz <= radius; dz++) {
                double dist = Math.sqrt(dx * dx + dz * dz);
                if (dist > radius) {
                    continue;
                }
                set(dx, Y - 1, dz, Material.STONE_BRICKS);
                Material top;
                if (dist >= radius - 1) {
                    top = Material.CYAN_CONCRETE;
                } else if (dist >= radius - 3) {
                    top = Math.floorMod((int) Math.round(Math.atan2(dz, dx) * 8), 2) == 0 ? Material.SEA_LANTERN : Material.WHITE_CONCRETE;
                } else if (dist <= 9 && dist >= 8) {
                    top = Material.LIGHT_BLUE_CONCRETE;
                } else {
                    top = (Math.floorMod(dx, 4) < 2) == (Math.floorMod(dz, 4) < 2) ? Material.SMOOTH_QUARTZ : Material.QUARTZ_BLOCK;
                }
                set(dx, Y, dz, top);
            }
        }

        // victory podium in the middle
        fill(-3, Y + 1, -3, 3, Y + 1, 3, Material.QUARTZ_BLOCK);
        fill(-2, Y + 2, -2, 2, Y + 2, 2, Material.SMOOTH_QUARTZ);
        fill(-1, Y + 3, -1, 1, Y + 3, 1, Material.GOLD_BLOCK);
        set(0, Y + 4, 0, Material.GLOWSTONE);

        // four light pillars
        for (int sx : new int[]{-14, 14}) {
            for (int sz : new int[]{-14, 14}) {
                fill(sx, Y + 1, sz, sx, Y + 9, sz, Material.CHISELED_QUARTZ_BLOCK);
                set(sx, Y + 10, sz, Material.SEA_LANTERN);
            }
        }

        // station pedestals: shop, battle pass, play
        pedestal(-16, 0, Material.EMERALD_BLOCK);
        pedestal(16, 0, Material.GOLD_BLOCK);
        pedestal(0, -17, Material.DIAMOND_BLOCK);

        // the battle bus, floating above the podium
        int by = Y + 18;
        fill(-3, by, -9, 3, by + 2, 9, Material.LIGHT_BLUE_CONCRETE);
        fill(-3, by + 1, -9, 3, by + 1, 9, Material.WHITE_CONCRETE);
        fill(-2, by + 3, -6, 2, by + 3, 6, Material.WHITE_CONCRETE);
        fill(-3, by + 1, -10, 3, by + 2, -10, Material.GLASS);
        set(-2, by, -10, Material.GLOWSTONE);
        set(2, by, -10, Material.GLOWSTONE);
        for (int bx : new int[]{-5, 5}) {
            for (int bz : new int[]{-6, 6}) {
                set(bx, by + 1, bz, Material.BLACK_CONCRETE);
                set(bx, by + 2, bz, Material.BLACK_CONCRETE);
            }
        }

        holo(0.5, Y + 8, 0.5, "&6&l\u2605 FROSTING ROYALE \u2605");
        holo(0.5, Y + 7.4, 0.5, "&7Last one standing wins the Victory Royale");
        holo(-15.5, Y + 5, 0.5, "&a&lITEM SHOP");
        holo(-15.5, Y + 4.5, 0.5, "&7Right-click the emerald in your hotbar");
        holo(16.5, Y + 5, 0.5, "&e&lBATTLE PASS");
        holo(16.5, Y + 4.5, 0.5, "&7Earn tiers, unlock rewards");
        holo(0.5, Y + 5, -16.5, "&b&lPLAY");
        holo(0.5, Y + 4.5, -16.5, "&7Use the compass to join a match");
    }

    private void pedestal(int x, int z, Material block) {
        fill(x - 1, Y + 1, z - 1, x + 1, Y + 1, z + 1, Material.QUARTZ_BLOCK);
        set(x, Y + 2, z, block);
        set(x, Y + 3, z, Material.GLASS);
    }
}
