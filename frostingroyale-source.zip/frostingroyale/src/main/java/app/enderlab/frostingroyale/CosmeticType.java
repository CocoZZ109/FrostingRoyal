package app.enderlab.frostingroyale;

import org.bukkit.Material;

public enum CosmeticType {
    TRAIL("Trail", Material.BLAZE_POWDER),
    KILL_FX("Kill Effect", Material.TNT),
    TITLE("Title", Material.NAME_TAG);

    private final String display;
    private final Material icon;

    CosmeticType(String display, Material icon) {
        this.display = display;
        this.icon = icon;
    }

    public String display() {
        return display;
    }

    public Material icon() {
        return icon;
    }
}
