package app.enderlab.frostingroyale;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/** /play, /lobby, /shop, /pass, /locker, /stats, /coins and the operator command /admin. */
public final class RoyaleCommands implements CommandExecutor, TabCompleter {

    private final FrostingRoyale plugin;

    public RoyaleCommands(FrostingRoyale plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String name = command.getName().toLowerCase(Locale.ROOT);
        if (name.equals("admin")) {
            admin(sender, args);
            return true;
        }
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        switch (name) {
            case "play" -> plugin.menus().play(player);
            case "lobby" -> {
                plugin.toLobby(player);
                Text.send(player, "&7Welcome back to the lobby!");
            }
            case "shop" -> plugin.menus().itemShop(player);
            case "pass" -> plugin.menus().pass(player, 0);
            case "locker" -> plugin.menus().locker(player);
            case "stats" -> plugin.menus().stats(player);
            case "coins" -> {
                PlayerData data = plugin.data().get(player);
                Text.send(player, "&7You have &6" + data.coins + " coins &7and Battle Pass tier &e" + BattlePass.level(data) + "&7.");
            }
            default -> {
            }
        }
        return true;
    }

    // ------------------------------------------------------------------ admin

    private void admin(CommandSender sender, String[] args) {
        if (!sender.hasPermission("frostingroyale.admin")) {
            Text.send(sender, "&cYou don't have permission to use this command.");
            return;
        }
        if (args.length == 0) {
            if (sender instanceof Player player) {
                plugin.adminMenus().main(player);
            } else {
                usage(sender);
            }
            return;
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "event" -> event(sender, args);
            case "endevents" -> plugin.events().endAll();
            case "coins" -> coins(sender, args);
            case "xp" -> xp(sender, args);
            case "pass" -> pass(sender, args);
            case "start" -> {
                if (!plugin.match().forceStart()) {
                    Text.send(sender, "&cNobody is in the queue, or a match is already running.");
                }
            }
            case "end" -> plugin.match().forceEnd();
            case "setcenter" -> {
                if (sender instanceof Player player) {
                    plugin.setCenterFrom(player);
                }
            }
            case "pregen" -> plugin.pregen(sender instanceof Player player ? player : null);
            case "maintenance" -> {
                boolean on = args.length > 1 ? args[1].equalsIgnoreCase("on") : !plugin.admin().maintenance();
                plugin.admin().setMaintenance(on);
                Text.send(sender, "&7Maintenance mode is now " + (on ? "&aON" : "&cOFF") + "&7.");
            }
            case "shutdown" -> {
                int seconds = 60;
                if (args.length > 1) {
                    try {
                        seconds = Integer.parseInt(args[1]);
                    } catch (NumberFormatException e) {
                        Text.send(sender, "&cUse a number of seconds, like /admin shutdown 120");
                        return;
                    }
                }
                plugin.admin().scheduleShutdown(seconds, "maintenance");
            }
            case "cancel" -> plugin.admin().cancelShutdown();
            case "stop" -> plugin.admin().stopNow("emergency stop");
            case "broadcast" -> {
                if (args.length < 2) {
                    usage(sender);
                    return;
                }
                String message = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
                for (Player player : Bukkit.getOnlinePlayers()) {
                    player.sendMessage(Text.plain("&6&lANNOUNCEMENT &8\u00BB &f" + message));
                }
            }
            default -> usage(sender);
        }
    }

    private void event(CommandSender sender, String[] args) {
        if (args.length < 3) {
            usage(sender);
            return;
        }
        EventManager.Type type = switch (args[1].toLowerCase(Locale.ROOT)) {
            case "sale" -> EventManager.Type.SALE;
            case "free" -> EventManager.Type.FREE_SHOP;
            case "coins" -> EventManager.Type.DOUBLE_COINS;
            case "xp" -> EventManager.Type.DOUBLE_XP;
            case "loot" -> EventManager.Type.LOOT_FRENZY;
            default -> null;
        };
        if (type == null) {
            usage(sender);
            return;
        }
        try {
            int minutes = Math.max(1, Integer.parseInt(args[2]));
            int value = type == EventManager.Type.SALE ? 50 : type == EventManager.Type.FREE_SHOP ? 100 : 2;
            if (type == EventManager.Type.SALE && args.length > 3) {
                value = Math.max(1, Math.min(99, Integer.parseInt(args[3])));
            }
            plugin.events().start(type, value, minutes);
        } catch (NumberFormatException e) {
            Text.send(sender, "&cMinutes and percent must be whole numbers.");
        }
    }

    private void coins(CommandSender sender, String[] args) {
        if (args.length < 4) {
            usage(sender);
            return;
        }
        Player target = Bukkit.getPlayerExact(args[2]);
        if (target == null) {
            Text.send(sender, "&cThat player is not online.");
            return;
        }
        try {
            long amount = Long.parseLong(args[3]);
            PlayerData data = plugin.data().get(target);
            switch (args[1].toLowerCase(Locale.ROOT)) {
                case "give" -> data.coins = Math.max(0, data.coins + amount);
                case "take" -> data.coins = Math.max(0, data.coins - amount);
                case "set" -> data.coins = Math.max(0, amount);
                default -> {
                    usage(sender);
                    return;
                }
            }
            Text.send(sender, "&6" + target.getName() + " &7now has &6" + data.coins + " coins&7.");
        } catch (NumberFormatException e) {
            Text.send(sender, "&cThe amount must be a whole number.");
        }
    }

    private void xp(CommandSender sender, String[] args) {
        if (args.length < 3) {
            usage(sender);
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            Text.send(sender, "&cThat player is not online.");
            return;
        }
        try {
            plugin.data().addXp(target, Long.parseLong(args[2]));
            Text.send(sender, "&7Gave &d" + args[2] + " XP &7to &6" + target.getName() + "&7.");
        } catch (NumberFormatException e) {
            Text.send(sender, "&cThe amount must be a whole number.");
        }
    }

    private void pass(CommandSender sender, String[] args) {
        if (args.length < 3) {
            usage(sender);
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            Text.send(sender, "&cThat player is not online.");
            return;
        }
        boolean give = args[2].equalsIgnoreCase("give");
        plugin.data().get(target).premium = give;
        Text.send(sender, "&6" + target.getName() + " &7" + (give ? "now has" : "no longer has") + " the Premium Pass.");
    }

    private void usage(CommandSender sender) {
        Text.send(sender, "&7Admin commands:");
        String[] lines = {
                "&6/admin &7- open the admin panel",
                "&6/admin event <sale|free|coins|xp|loot> <minutes> [percent] &7- host an event",
                "&6/admin endevents &7- end all events",
                "&6/admin coins <give|take|set> <player> <amount>",
                "&6/admin xp <player> <amount> &7- give Battle Pass XP",
                "&6/admin pass <player> <give|remove> &7- premium pass",
                "&6/admin start &7| &6end &7- force start / end the match",
                "&6/admin setcenter &7- use your position as the map centre",
                "&6/admin pregen &7- pre-generate the map",
                "&6/admin maintenance [on|off] &7| &6shutdown [seconds] &7| &6cancel &7| &6stop",
                "&6/admin broadcast <message>"};
        for (String line : lines) {
            sender.sendMessage(Text.plain(line));
        }
    }

    // ------------------------------------------------------------------ tab complete

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (!command.getName().equalsIgnoreCase("admin") || !sender.hasPermission("frostingroyale.admin")) {
            return result;
        }
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.addAll(List.of("event", "endevents", "coins", "xp", "pass", "start", "end", "setcenter", "pregen",
                    "maintenance", "shutdown", "cancel", "stop", "broadcast"));
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "event" -> options.addAll(List.of("sale", "free", "coins", "xp", "loot"));
                case "coins" -> options.addAll(List.of("give", "take", "set"));
                case "xp", "pass" -> addPlayers(options);
                case "maintenance" -> options.addAll(List.of("on", "off"));
                default -> {
                }
            }
        } else if (args.length == 3) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "coins" -> addPlayers(options);
                case "pass" -> options.addAll(List.of("give", "remove"));
                default -> {
                }
            }
        }
        String prefix = args[args.length - 1].toLowerCase(Locale.ROOT);
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(prefix)) {
                result.add(option);
            }
        }
        return result;
    }

    private void addPlayers(List<String> list) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            list.add(player.getName());
        }
    }
}
