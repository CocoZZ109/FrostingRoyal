FrostingRoyale
==============

Install
-------
1. Put FrostingRoyale.jar in your server's plugins/ folder (Paper 26.2). No other plugins are needed.
2. Start the server. It creates two worlds by itself:
   - frostingroyale_lobby: a glowing lobby island (built automatically)
   - frostingroyale_arena: the normal Minecraft world where matches are played
3. Everyone who joins lands in the lobby.

First-time setup (operators)
----------------------------
1. Open /admin > Match Control > "Go to the match world" and fly to land you like
   (a big area of land, not ocean), then /admin setcenter.
2. Run /admin pregen once. It prepares the map in the background so matches start smoothly.

Playing
-------
Compass or /play: join the queue. If not enough players join, bots (zombies and skeletons) fill in.
Everyone glides down with an elytra, loots chests, and the storm (world border) closes in.
Last one standing wins. Coins and Battle Pass XP are earned from placement and eliminations.

/play    play menu          /shop   daily Item Shop        /pass     Battle Pass
/locker  trails, kill effects, titles, start packs        /stats    your stats
/coins   your coins         /lobby  go back to the lobby (aliases /hub /spawn /leave)

Shop
----
Item Shop: 8 cosmetics that rotate every day. Boosts (2x coins, 2x XP), the Premium Pass,
tier skips and one-use Start Packs. Every purchase asks you to confirm.

Operators
---------
/admin opens the chest panel:
  Host an Event   shop sale (25/50/75%), FREE SHOP, double coins, double XP, loot frenzy
  Match Control   force start/end, skip storm phase, supply drop, pregen, set map centre
  Giveaways       coins or Battle Pass XP for everyone online
  Server Control  maintenance mode, shutdown countdown, emergency stop
Commands: /admin event <sale|free|coins|xp|loot> <minutes> [percent], /admin endevents,
/admin coins <give|take|set> <player> <n>, /admin xp <player> <n>, /admin pass <player> <give|remove>,
/admin start, /admin end, /admin setcenter, /admin pregen, /admin maintenance [on|off],
/admin shutdown [seconds], /admin cancel, /admin stop, /admin broadcast <message>
Note: "stop" shuts the server down. Your host must restart it (most hosts do this automatically).
